/**
 * 
 * @author Anthony Hackney hackn1a
 * Date: 01/10/19
 * 
 * This class creates a new reliability rating from multiple factors 
 */
public class Product {

	private String modelName; //Field for model name
	private String manuName; //field for manufaterors name
	private double retailPrice; // retail price
	private char overallRating; // the overall rating of the product
	private double relRating; // the relative rating
	private int surveyCustomers; //the number of surveyCustomers
	
	/**
	 * 
	 * @param modelName
	 * @param manuName
	 * 
	 */
	public Product(String modelName, String manuName) {
		this(modelName, manuName, 0);
	}
	/**
	 * 
	 * @param modelName
	 * @param manuName
	 * @param retailPrice
	 * 
	 */
	public Product(String modelName, String manuName, double retailPrice) {
		this.modelName = modelName;
		this.manuName = manuName;
		this.retailPrice = retailPrice;
	}
	
	public String getModelName() {
		return modelName;
	}
	
	public String getManuName() {
		return manuName;
	}
	public double getRetailPrice() {
		return retailPrice;
	}

	public void setRetailPrice(double retailPrice) {
		this.retailPrice = retailPrice;
	}
	
	public char getOverallRating() {
		return overallRating;
	}
	
	public void setOverallRating(char overallRating) {
		this.overallRating = overallRating;
	}
	/**
	 * 
	 * @param relRating
	 * @param surveyCustomers
	 * @return this returns the average reliability  
	 */
	public double getRelRating() {
		double avgReliability = 0.0;
		avgReliability = relRating/surveyCustomers;
		relRating = avgReliability;
		return relRating;
	}
	
	public int getSurveyCustomers() {
		return surveyCustomers;
	}
	/**
	 * 
	 * @param customerRelRating
	 * @return returns the new reliability rating after a new customer submits their 
	 * raiting
	 */
	public double rateReliability(double reliabilityRating) {
		double temp = 0.0;
		if(surveyCustomers == 1){
			return relRating;
		}else
		for(int i = 0; i<surveyCustomers; i++) {
			temp = (getRelRating() * (surveyCustomers - 1) + reliabilityRating)/surveyCustomers;  			
		}
		reliabilityRating = temp;
		return reliabilityRating;
	}
	

}
