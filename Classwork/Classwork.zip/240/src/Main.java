
public class Main {

	public static void main(String[] args) {
		Product product = new Product("name", "name", 4.5);
		
		Product product2 = new Product("name 2"," name 2",2);
		
		System.out.println(product);

	}

}
