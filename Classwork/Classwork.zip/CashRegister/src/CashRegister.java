/*
 * PID: H2
 * Author: 	Anthony Hackney
 * Date:   	01/31/18
 *
 * Description:  Program takes in information from the 
 * customer and calculates their total receipt
 */
import java.util.Scanner;

public class CashRegister {

	public static void main(String[] args) {

		double ticketTod = 0.0;
		double ticketChld = 0.0;
		double ticketAdult = 0.0;
		double subTotal = 0.0;
		double finalTotal = 0.0;
		double finalTaxrate = 0.0;
		String userInput;
		char Member;
		double partyDiscount = 0.0;
		double Discount = 0.0;
		final double TAX_RATE = .06;
		
		// initial scanner//
		Scanner scnr = new Scanner(System.in);
		
		// Step 1 welcome user
		System.out.println("Welcom to Chip's Bouncing Castle!");
		
		// Step 2 prompt user
		System.out.println("Are you a memeber? [y/n]");
		userInput = scnr.next();
		Member = userInput.charAt(0);
		if (Member == 'y' || Member == 'Y') {
			Member = 0;
		} else {
			Member = 1;
		}
		
		System.out.println("How many toddlers?: ");
		ticketTod = scnr.nextDouble();
		System.out.println("How many youngsters?: ");
		ticketChld = scnr.nextDouble();
		System.out.println("How many adults?: ");
		ticketAdult = scnr.nextDouble();
		
		// Step 3 repeat the order to the customer
		System.out.println("Order summary...");
		System.out.println((int) ticketTod + " toddler(s)");
		System.out.println((int) ticketChld + " youngster(s)");
		System.out.println((int) ticketAdult + " adult(s)");

		// Step 4 calculate the totals and the discounts
		if (ticketChld + ticketTod + ticketAdult >= 10) {
			partyDiscount = .2;
		} else if (ticketChld + ticketTod + ticketAdult >= 5) {
			partyDiscount = .1;
		} else {
			partyDiscount = 0;
		}
		if (partyDiscount == 0) {
			Discount = 0;
		}
		subTotal = ((ticketTod * 1.50) + (ticketChld * 2.00) 
				+ (Member * ticketAdult * 3.00));
		Discount = (subTotal * partyDiscount);
		finalTaxrate = (subTotal - Discount) * TAX_RATE;
		finalTotal = (finalTaxrate + (subTotal - Discount));
		
		// Step 5 print the total to the customer
		System.out.println("");
		System.out.println("---------------");
		System.out.println("Subtotal: $" + subTotal);
		System.out.println("Discount: $" + Discount);
		System.out.println("Tax: $" + finalTaxrate);
		System.out.println("Total: $" + finalTotal);
		System.out.println("Thank you for your order!");

		scnr.close();
	}

}
