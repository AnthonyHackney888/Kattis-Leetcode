/*
 ============================================================================
 Name        : FindMax.c
 Author      : hackn1a
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
void printArray(int * array, int n);
int populateArray(int * array, int n);
int findMax(int * array, int n);

int main(void) {
	int num = 9;

	int *ptr;
	ptr = &num;

	printf("%o", *ptr);
	return 0;
}
int populateArray(int * array, int n){
	for(int i = 0; i<=n;i++){
		array[i] = rand() %10;
		*(array + i) = i;
	}
	return 0;
}
void printArray(int * array, int n){
	for(int i = 0; i < n; i++){
		array[i] = i;
		printf("%d", *array++);
	}
}

int findMax(int * array, int n){
	int *max = 0;
	max = array;
	for(int i = 0; i <n;i++){
		if(*(array +i)> *max){
			max = array + i;
		}
	}
	return *max;
}

