package corrections;

import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		System.out.println(Arrays.toString(method(new int[] { 1, 2,3,4,5 })));

	}
	/**
	 * This method sorts the integers in the array and places them in order from highest to lowest
	 * @param array - array given in the main method
	 * @return the sorted array 
	 */
	public static int[] method(int[] array) {
		// create local variable to hold a temp value
		int index = 0;
		//while the index is less than the length of the array + 1 
		// then divided by 2
		//so it stops at the second element
		while (index < (array.length + 1) / 2) {
			int temp = array[index];
			//set temp equal to array[i]
			//0 at first
			
			//looks for an element at the other end of the array and swaps it with an element at
			//the beginning 
			array[index] = array[array.length - index - 1];
			array[array.length - index - 1] = temp;
			index++;
			//increment by 1
		}
		return array;
	}
}
