package corrections;

import java.util.ArrayList;

public class checkAvailability {
	ArrayList<String> Media = new ArrayList<>();
	/**
	 * This method checks the availability of a media item
	 * first by parsing through the arrayList and checking if the 
	 * MediaID is present and then by checking if mediaId 
	 * is available with the isAvailable method
	 * @param mediaID - the media items that are in the Media ArrayList
	 * @return true or false dependent on if the media item is there and available
	 */
	public boolean checkedAvailability(String mediaID) {
		// loop through the Media arraylist and if
		// it contains mediaID return true
		for (int i = 0; i < Media.size(); i++) {
			if (Media.contains(mediaID)) {
				// also checks if the mediaID is available
				if (mediaID.isAvailable()) {
					return true;
				}
			}

		}//if not it returns false
		return false;

	}

}
