package corrections;
/**
 * 
 * @author hackn1a
 * 
 * This program takes in width and height from the abstract Shape class
 * and calculates the area and checks if it is a square by checking if height and width are
 * the same value
 */
public class Rectangle extends Shape {
	
	/**
	 *This method takes the height and width from the
	 *Shape interface and multiplies them to get the area
	 *@return area- returns the area of the width and height of a shape 
	 */
	public double getArea() {
	double area; // local variable for area
	area = height * width;
		return area;
	}
	/**
	 * This method checks if the width and height are the same
	 * and if they are it is a square so it will return true
	 * @return true or false
	 */
	public boolean isSquare() {
		//if the height and width are the same
		//return true
		if(height == width) {
		return true;	
		}else {
			return false;
		}
		
	}

}
