/*
 ============================================================================
 Name        : pretest.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include<conio.h>

void min(double data[], int n, double *smallest);
int sumit(int data[], int n);
int main(void) {

	float num1, num2;
	num1 = 12;
	num2 = 22;
	printf("The pre-swapped number 1 is: %f\n", num1);
	printf("The pre-swapped number 2 is: %f\n", num2);

	fswap(&num1, &num2);

	printf("the swapped number 1 is now: %f\n", num1);
	printf("the swapped number 2 is now: %f\n", num2);
	return 0;
}

int sumit(int data[], int n) {
	int sum = 0;

	for (int i = 0; i < n; i++)
		sum += data[i];

	return sum;
}

void min(double data[], int n, double *smallest) {
	smallest = data;
	*smallest = *data;
	for (int i = 0; i < n; i++) {
		if (*(data + i) < *smallest) {
			*smallest = *(data + i);
		}
	}
}

void fswap(float *f1, float *f2) {

	float temp;

	temp = *f2;
	*f2 = *f1;
	*f1 = temp;

}
