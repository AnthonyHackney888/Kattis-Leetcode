
/*
 * PID: H4
 * Author: 	Anthony Hackney
 * Date:   	04/03/18
 *
 * Description: Use a multidimensional array to use data taken from an
 * intersection and print out the accidents, vehicles, and accident rates 
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class TrafficDataProcessor {

	public static final int NUM_INTERSECTIONS = 12;

	public static void main(String[] args) {
		try {
			// Step 1 initialize the file reader
			File file = new File("traffic.txt");
			FileReader fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String line;
			String[] temp;
			// Step 2 initialize arrays for NUM_INTERSECTIONS
			int[] vehicles = new int[NUM_INTERSECTIONS];
			int[] accidents = new int[NUM_INTERSECTIONS];
			double[] rate = new double[NUM_INTERSECTIONS];
			int maxAccidents = 0;
			int maxRate = 0;
			// Step 3 while loop to read in from a file
			while ((line = bufferedReader.readLine()) != null) {
				temp = line.split(" ");
				int temp1 = Integer.parseInt(temp[0].trim());
				int temp2 = Integer.parseInt(temp[1].trim());
				int temp3 = Integer.valueOf(temp1);

				vehicles[temp3] = vehicles[temp3] + 1;
				if (temp2 > 500) {

					accidents[temp3]++;
				}

			}
			for (int loop = 0; loop < NUM_INTERSECTIONS; loop++) {

				rate[loop] = (double) accidents[loop] / (double) vehicles[loop];
			}
			// Step 4 print out accident rate
			System.out.println("ID \t Num. of Vehicles \t Num." + " of Accidents \t Accident Rate");
			System.out.println("------------------------------------------"
					+ "---------------------------------------------------");
			for (int loop = 0; loop < NUM_INTERSECTIONS; loop++) {
				System.out.print(loop);
				System.out.print("\t\t\t");
				System.out.print(vehicles[loop]);
				System.out.print("\t\t\t");
				System.out.print(accidents[loop]);
				System.out.print("\t\t\t");
				System.out.print(rate[loop]);
				System.out.print("\n");
			}

			// Step 5 caluclate highest accidents and rate

			for (int loop = 0; loop < NUM_INTERSECTIONS; loop++) {
				if (accidents[loop] > accidents[maxAccidents]) {
					maxAccidents = loop;
				}
				if (rate[loop] > rate[maxRate]) {
					maxRate = loop;
				}
			}

			// Step 6 print out the highest accident rate & Most accidents

			System.out.println("Most accidents at any intersection: " + maxAccidents);
			System.out.println("Higest accedent rate at any intersection: " + rate[maxRate]);
			System.out.println("Intersections with a high average traversal time: " + maxRate);

			fileReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}