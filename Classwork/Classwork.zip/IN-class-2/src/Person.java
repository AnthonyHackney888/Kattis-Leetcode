
public class Person {
	//Step 2 create two private variables for the names and ages
	private int age; //The persons age
	private String name; //The persons name
	/**
	 * Constructor
	 * @param age the age of the people
	 * @param name the name of the people
	 */

public Person(int P_age, String P_name) {
	age = P_age;
	name = P_name;
}
public void setName(String P_name) {
	name = P_name;
}
public String getName() {
	
	return name;
}
public void setAge(int P_age) {
	age = P_age;
}
public int getAge() {
	return age;
}
/**
 * the copy constructor
 */
public Person(Person person2, int P_age, String P_name) {
	
	P_age = person2.age;
	P_name = person2.name;
}
public Person() {
	// TODO Auto-generated constructor stub
}
public Person copy(int P_age, String P_name) {
	// TODO Auto-generated method stub
	return person1;
}

}
