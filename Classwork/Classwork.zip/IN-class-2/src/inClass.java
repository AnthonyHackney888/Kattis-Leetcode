
public class inClass {

	public static void main(String[] args) {
		//Step 1 create new objects for 3 different people
		Person person1 = new Person();
		//Step 2 have person 1 and person 2 be twins
		Person person2 = person1;
		
		Person person3 = new Person();
		
		
		person1.setName("Jon");
		
		person1.setAge(10);
		
		person3.setAge(15);
		
		person3.setName("sure");
		System.out.println("This is the person 1 & 2s name " + person1.getName());
		
		System.out.println("Their age " + person1.getAge());
		
		System.out.println("person 3s name " + person3.getName());
		
		System.out.println("their age " + person3.getAge());
		
		
		if(person1.equals(person2)) {
		
			System.out.print("equal");
			
		}else {
			System.out.print("not equal");
		}
		
	}

}
