/*
 ============================================================================
 Name        : Part.c
 Author      :Anthony Hackney,hackn1a
 Version     :
 Copyright   : Your copyright notice
 Description : This program does stuff with pointers
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
int getSumByAddress(int * n, int * m);
int main(void) {
	//initialize variables
	int m = 29;
	int n = 34;
	int * pm;
	//print the value and the address of m
	printf("The value of m: \t%d\n", m);
	printf("The address of m is:\t%X\n", &m);
	//print the value and the address of n
	printf("The value of n: \t%d\n", n);
	printf("The address of n is:\t%X\n", &n);

	pm = &m;

	printf("The address of pm is:\t%X\n", &pm);
	printf("The value of m: \t%d\n", pm);
	printf("dereferencing pm:\t%d\n", *pm);

	pm = &n;
	printf("The address of pm is:\t%X\n", &pm);
	printf("The value of m: \t%d\n", pm);
	printf("dereferencing pm:\t%d\n", *pm);
	//the sum using two different adress points
	printf("The sum of two address points:\t%d\n", getSumByAddress( &n, &m));
	return 0;
}
/*
 * This method adds two address points
 */
int getSumByAddress(int * n, int * m){
	int sum;
	sum = *n + *m;

	return sum;
 }

