
/*
 * PID: H7
 * Author: 	Anthony Hackney
 * Date:   	04/26/18
 *
 * Description: Takes in a set array and using multiple methods scramble
 * the words as well as keep track of how many tries the user took. 
 * Then display the correct guess count and the correct words
 */

import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class WordScramble {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		// Step 1 initialize variables

		int correctGuessCount = 0;
		String scrambledWord = "";
		String guessedWord = "";
		// Step 2 create an array for words
		String words[] = { "ilovecps180", "fireupchips!", "safesummer" };
		// Step 3 start a for loop to read in from another method
		for (int i = 0; i < words.length; i++) {
			scrambledWord = scramWord(words[i]);
			// Step 4 prompt the user to unscramble words
			System.out.print("Unscramble " + "'" + scrambledWord + 
					"'" + " (" + scrambledWord.length() + " letters): ");
			// Step 5 count the number of trials
			for (int numTrials = 0; numTrials < 3; numTrials++) {
				guessedWord = scanner.nextLine();
				// Step 5 check if the input equals the provided words
				if (guessedWord.equals(words[i])) {
					System.out.println("Excellent, you guessed it.");
					correctGuessCount++;
					break;
					// Step 6 check the amount of trials the user needed
				} else if (numTrials == 0 || numTrials == 1) {
					System.out.print("No, try again: ");
				} else {
					System.out.println("Too bad.");
				}
			}
		}
		// Step 7 display the correct words and the correct guess count
		System.out.println("The correct answers are: " + words[0] 
				+ " " + words[1] + " " + words[2]);
		System.out.println("You successfully unscrambled " 
				+ correctGuessCount + " words(s). Great!");
	}

	/**************************************************************************
	 * scramWord - the method scrambles the words into a character array
	 * 
	 * 
	 * String - using the scramble parameter to read in the array form 
	 * the main and scramble the letters in another method 
	 * scrambledWord - returns the scrambled
	 * letters back into the main
	 */
	public static String scramWord(String scramble) {
		//Step 8 create another char array to take in the letters
		//from the array and initialize any variables
		Character[] wordchar = new Character[scramble.length()];
		String scrambledWord = "";
		//Step 9 scramble the letters using a for loop
		for (int i = 0; i < scramble.length(); i++) {
			wordchar[i] = new Character(scramble.charAt(i));
		}
		java.util.List<Character> charList = Arrays.asList(wordchar);
		Collections.shuffle(charList);

		// Step 10 change the char back into the String array
		for (int i = 0; i < scramble.length(); i++) {
			scrambledWord = scrambledWord + charList.get(i);
		}
		// Step 11 return the scrambled words back to main
		return scrambledWord;
	}
}
