package bank;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
/**
 * 
 * @author hackn1a
 *	This class checks if the person is in the database
 *	and if they are then it logs them in and they can then 
 *	deposit or withdrawls
 */
public class loginWindow {

	private JFrame frame;
	private JTextField username;
	private JPasswordField passwordField;
	Proxy prox = new Proxy(); //creates the reference to the proxy class
	BankingSystem bankingSystem = BankingSystem.getInstance(); //singlton referece to the bankingsystem class

	/**
	 * Launch the application.
	 */
	public static void newWindow() {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loginWindow window = new loginWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public loginWindow() {
		initialize();

	}

	/** 
	 * Initialize the contents of the frame.
	 * As well it holds the logic for logging in to a database
	 */
	private void initialize() {
		frame = new JFrame("login");
		frame.setBounds(100, 100, 246, 229);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		username = new JTextField();
		username.setBounds(25, 69, 184, 20);
		frame.getContentPane().add(username);
		username.setColumns(10);
		username.grabFocus();
		JLabel lblNewLabel = new JLabel("Username:");
		lblNewLabel.setBounds(25, 46, 69, 14);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Password:");
		lblNewLabel_1.setBounds(25, 100, 132, 14);
		frame.getContentPane().add(lblNewLabel_1);

		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {

				try {
					prox.readFile();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String pass = passwordField.getText();
				String name = username.getText();
				Map<String, String> hashM = Proxy.getHash();
				//checks if the login credentials worked
				if(hashM.containsKey(name) && hashM.get(name).equals(pass)) {
					JOptionPane.showMessageDialog(frame, "Nice!");
					frame.dispose();
				}
				//if else to validate the login
				if (name.isEmpty()) {
					JOptionPane.showMessageDialog(frame, "Enter your username");
				}
				if (pass.isEmpty()) {
					JOptionPane.showMessageDialog(frame, "Password must contain a number and a capital letter");
				} else if (!pass.matches("[A-Za-z0-9 ]*")) {
					JOptionPane.showMessageDialog(frame, "Password must contain a number and a capital letter");
				} else if (pass.length() < 8) {
					JOptionPane.showMessageDialog(frame, "Password contain 8 letters and or numbers");
				} 
			}
		});
		btnNewButton.setBounds(96, 156, 113, 23);
		frame.getContentPane().add(btnNewButton);

		passwordField = new JPasswordField();
		passwordField.setBounds(25, 124, 184, 21);
		frame.getContentPane().add(passwordField);
	}
	/**
	 * This method checks the file if the person is in the file
	 * and if not it will return false
	 * @return returns the hashmaps containing the name and password of the login
	 * @throws FileNotFoundException if the file is not present throws an exception
	 */
	public boolean verify() throws FileNotFoundException {
		prox.readFile();
		String name = username.getText();
		String pass = passwordField.getText();
		Map<String, String> hashmap = Proxy.getHash();
		return hashmap.containsKey(name) && hashmap.get(name).equals(pass);
	}
}
