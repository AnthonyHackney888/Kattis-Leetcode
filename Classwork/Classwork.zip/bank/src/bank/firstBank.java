package bank;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
/**
 * 
 * @author hackn1a
 *	This program adds on to a banking system. It adds a GUI element for a person to add a user or login
 *	And can then work in the Terminal to withdraw or deposit
 */
public class firstBank {

	private JFrame frame;
	private firstBank bank;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					firstBank window = new firstBank();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public firstBank() {
		initialize();
	}

	/**
	 * 
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Banking Window");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//button to create an account
		JButton btnNewButton = new JButton("Create Account");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent creatEvent) {
				
				try {
					createAccount.newWindow();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				frame.dispose();
			}
		});
		btnNewButton.setBounds(104, 187, 216, 23);
		//label of the a joke company 
		JLabel lblFirstBankOf = new JLabel("First Bank of Anthony");
		lblFirstBankOf.setBounds(166, 64, 179, 36);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(btnNewButton);
		frame.getContentPane().add(lblFirstBankOf);
		//a button to choose to login
		JButton btnNewButton_1 = new JButton("Login");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent loginEvent) {
				
				loginWindow.newWindow();
				frame.dispose();
			}
		});
		btnNewButton_1.setBounds(104, 128, 216, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblOr = new JLabel("or");
		lblOr.setBounds(206, 162, 23, 14);
		frame.getContentPane().add(lblOr);
	}

}
