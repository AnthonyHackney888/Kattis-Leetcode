package bank;
import java.math.BigDecimal;

public class CheckingAccount extends Account {
	/**
	 * 
	 * @param accountNumber persons account number
	 * @param balence Checking account balence
	 */
	public CheckingAccount(int accountNumber, BigDecimal balence) {
		super(accountNumber, balence);
		
	}
	/**
	 * 	A withdraw method that subtracts the requested amount 
	 * and if there is less than zero will inform the person that they
	 * are overdrawn
	 */
	@Override
	public boolean withdraw(BigDecimal balence) {
		super.setBalence(super.getBalence().subtract(balence));
		if(super.getBalence().compareTo(BigDecimal.ZERO)<0) {
			System.out.println("The account was overdrawn");
		}
		System.out.println("The checking balence is: $" + getBalence());
		return true;
	}
	/**
	 * A deposit method to add funds to the account
	 * @return 
	 */
	@Override
	boolean deposit(BigDecimal balence) {
		super.setBalence(super.getBalence().add(balence));
		System.out.println("The checking balence is: $" + getBalence());
		return true;
	}

}
