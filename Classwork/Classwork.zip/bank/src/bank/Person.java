package bank;

public class Person {
	//initialize variables
	private String name, lastName, licenseNumber;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLicenseNumber() {
		return licenseNumber;
	}

	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	public Person(String name, String lastName, String licenseNumber) {
		super();
		this.name = name;
		this.lastName = lastName;
		this.licenseNumber = licenseNumber;
	}
}
