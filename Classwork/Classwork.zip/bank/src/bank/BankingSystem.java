package bank;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;





public class BankingSystem {
	// initialize the Hashmap database to hold a persons bank account
	private Map<String, ArrayList<Account>> database = new HashMap<String, ArrayList<Account>>();
	private static BankingSystem oneInstance = new BankingSystem();
	public static BankingSystem getInstance() {
		return oneInstance;
	}
	
	/**
	 * 
	 * @param person  variable to interact with the Person class
	 * @param account variable to interact with the Account class
	 * @return- boolean statement depending on if the if else is true or false
	 */
	boolean verifyAccountExists(Person person, Account account) {
		ArrayList<Account> accounts = database.get(person.getLicenseNumber()); // array list to hold the persons bank
																				// information
		// if else to see if the accounts Array List is not empty
		if (accounts != null) {
			for (int i = 0; i < accounts.size(); i++) {
				if (accounts.get(i).getAccountNumber() == (account.getAccountNumber())) {
					return true;
				}
			}
		}

		return false;
	}
	public boolean removePerson(Person person) {
		//if the person is NOT within the system an Exception was thrown
		if (database.get(person.getLicenseNumber()) == null) {
			throw new PersonDoesNotExistsException(person.getName() + " does not exist");
			

		}
		database.remove(person.getLicenseNumber());
		System.out.println("Person removed");//To show a person was removed
		return true;
	}
	/**
	 * 
	 * @param person variable to interact with the Person class
	 */
	public void addPerson(Person person) {
		//if the person is already in the system an exception is thrown
		if (database.get(person.getLicenseNumber()) != null) {
			throw new PersonAlreadyExistsException(person.getName() + " already exists");
		}
		
		database.put(person.getLicenseNumber(), new ArrayList<Account>());	
		System.out.println("Person added");//to show if a person was added
		
		
		
	}

	/**
	 * 
	 * @param person  variable to interact with the Person class
	 * 
	 * @param account variable to interact with the Account class
	 */
	public boolean openAccount(Person person, Account account) {

		try {
			if (verifyAccountExists(person, account) == true) {
				//throw new AccountAlreadyExistsException("The account " + account.getAccountNumber() + " already exists");
				return false;

			}else {
				
			
			database.get(person.getLicenseNumber()).add(account);
			System.out.println("Account opened");//to show if an account was added
			return true;
			}
			} catch (AccountAlreadyExistsException e) {
			System.out.println(e);
		
		
		}
		return true;
	}

	/**
	 * 
	 * @param person  variable to interact with the Person class
	 * @param account variable to interact with the Account class
	 */
	public boolean closeAccount(Person person, Account account) {
		if (verifyAccountExists(person, account) == false) {
			//throw new AccountDoesNotExistsException("the account " + account.getAccountNumber() + " does not exist");
			return false;

		} else if (verifyAccountExists(person, account) == true) {
			database.get(person.getLicenseNumber()).remove(account);
			System.out.println("Account closed");//to show if an account was removed
		}
		return true;

	}
} 


class AccountAlreadyExistsException extends RuntimeException {
	private static final long serialVersionUID = -1070761751528533451L;

	public AccountAlreadyExistsException(String string) {
		super(string);
	}
}

class PersonAlreadyExistsException extends RuntimeException {
	public PersonAlreadyExistsException(String string) {
		super(string);
	}

	private static final long serialVersionUID = -3486910112207114966L;
}

class PersonDoesNotExistsException extends RuntimeException {
	public PersonDoesNotExistsException(String string) {
		super(string);
	}

	private static final long serialVersionUID = -54055476454261434L;
}
