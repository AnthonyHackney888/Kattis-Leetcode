package bank;
import java.math.BigDecimal;


public class Teller {
	private Person person;// have the teller be able to call the person class
	private BankingSystem bankingSystem;// have the teller be able to call the bankingSystem


	/**
	 * Constructor for the Teller class
	 * 
	 * @param name          sets the name of the teller and person
	 * @param lastName      sets the last name for the person
	 * @param licenseNumber sets the license number for the person
	 */
	public Teller(String name, String lastName, String licenseNumber) {
		this.person = new Person(name, lastName, licenseNumber);
		this.bankingSystem = bankingSystem.getInstance();

	}

	public Teller() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * A Withdraw method that interacts with the bankingSystem class and withdraws a
	 * certain specified amount
	 * 
	 * @param person  person variable from the Person class
	 * @param account account variable to find the account number from the Account
	 *                class
	 * @param amount  amount variable to interact with the Account class
	 */
	public boolean withdraw(Person person, Account account, BigDecimal amount) {

		if (bankingSystem.verifyAccountExists(person, account) == false) {
			//throw new AccountDoesNotExistsException(person.getName() + " doesn not exist");
			return false;

		} else {
			account.withdraw(amount);
			return true;
		} 


	}

	/**
	 * Deposit method that interacts with the banking system and deopsits a certain
	 * specified amount
	 * 
	 * @param person  person variable from the Person class
	 * @param account account variable to find the account number from the Account
	 *                class
	 * @param amount  amount variable to interact with the Account class
	 */
	public boolean deposit(Person person, Account account, BigDecimal amount) {
		if (bankingSystem.verifyAccountExists(person, account) == false) {
			//throw new AccountDoesNotExistsException(person.getName() + " does not exist");
			return false;

		} else {
			account.deposit(amount);
			return true;
		}
	
	}

	/**
	 * adds a person to the banking system
	 * 
	 * @param person person variable from the Person class interacts with both the
	 *               Person and BankingSystem class
	 * 
	 */
	public boolean addPerson(Person person) {
		bankingSystem.addPerson(person);
		return true;
	}

	/**
	 * removes a person from the banking system
	 * 
	 * @param person person variable from the Person class interacts with both the
	 *               Person and BankingSystem class
	 */
	public boolean removePerson(Person person) {
		bankingSystem.removePerson(person);
		return true;
	}

	/**
	 * opens a persons account
	 * 
	 * @param person  person variable from the Person class interacts with both the
	 *                Person and BankingSystem class
	 * @param account account variable to find the account number from the Account
	 *                class and interacts with the Bankning and Acount class
	 */
	public boolean openAccount(Person person, Account account) {
		bankingSystem.openAccount(person, account);
		return true;
	}

	/**
	 * closes a persons account
	 * 
	 * @param person  person variable from the Person class interacts with both the
	 *                Person and BankingSystem class
	 * @param account account variable to find the account number from the Account
	 *                class and interacts with the Bankning and Acount class
	 * 
	 */
	public boolean closeAccout(Person person, Account account) {
		bankingSystem.closeAccount(person, account);
		return true;

	}

	public Person getPerson() {
		return person;
	}

}
