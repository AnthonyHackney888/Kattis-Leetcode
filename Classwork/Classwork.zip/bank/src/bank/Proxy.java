package bank;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public class Proxy {
	private String username; //
	private String password;//
	private static HashMap<String, String> hash = new HashMap<>();//
	private Person person;//
	
	
	public Proxy(String username, String password, HashMap<String, String> hash, Person person) {
		this.username = username;
		this.password = password;
		this.hash = hash;
		this.person = person;
		
	}


	public Proxy() {
		// TODO Auto-generated constructor stub
	}

	public static HashMap<String, String> getHash() {
		return hash;
	}



	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public Person getPerson() {
		return person;
	}
	

	public void setHash(String username, String password,  Person person) {
		hash.put(username, password);
		this.person = person;
	}
	/**
	 * 
	 * @throws IOException
	 */
	public void writeFileData() throws IOException {
	BufferedWriter wr = new BufferedWriter(new FileWriter("database.txt"));
	
	for(String username : getHash().keySet()) {
		String key = username.toString();
		String value = getHash().get(key);
		wr.write(key + "=" + value + "");
	}
	wr.close();
	
	}
	/**
	 * 
	 * @throws IOException
	 */
	public void writeFileCred() throws IOException {
		BufferedWriter wr = new BufferedWriter(new FileWriter("Credentials.txt"));
		for(String username: getHash().keySet()) {
			String key = username.toString();
			String value = getHash().get(key);
			wr.write(key + " " + person.getLicenseNumber() +"");
		}
		wr.close();
	}
	public void readFile() throws FileNotFoundException {
	String line = "";
	BufferedReader reader = new BufferedReader(new FileReader("database.txt"));
	Scanner scnr = new Scanner(reader);
	while(scnr.hasNext()) {
			String []read =  scnr.nextLine().split("=");	
			getHash().put(read[0], read[1]);
			
	}
	
	
	}


}
