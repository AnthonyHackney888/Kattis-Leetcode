package bank;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Map;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
/**
 * 
 * @author hackn1a
 * This class creates a GUI for creating an account
 * Which then calls to the proxy class to add the person into the database
 */
public class createAccount {
	private JTextField firstNameField;
	private JFrame frame;
	private JTextField lastNameField;
	private JPasswordField passwordField;
	private JTextField LicenseField;
	Proxy prox = new Proxy();//creates a reference to the proxy class
	BankingSystem bankingsystem=BankingSystem.getInstance(); //creates a singleton referece to the bankingsystem class
	

	/**
	 * Launch the application.
	 * @throws FileNotFoundException 
	 */
	public static void newWindow() throws FileNotFoundException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					createAccount window = new createAccount();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		loginWindow check = new loginWindow();
		Scanner scnr = new Scanner (System.in);
		String userInput = "";
		while(!userInput.equals("exit")) {
			if(check.verify() == true) {
				
			}
			else {
				break;
			}
		}
	}

	/**
	 * Create the application.
	 */
	public createAccount() {
		initialize();
		

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Create Account");
		frame.setBounds(100, 100, 275, 311);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		//username textField
		lastNameField = new JTextField();
		lastNameField.setBounds(25, 139, 184, 20);
		frame.getContentPane().add(lastNameField);
		lastNameField.setColumns(10);
		lastNameField.grabFocus();
		//label for the username space
		JLabel lblNewLabel = new JLabel("Lastname:");
		lblNewLabel.setBounds(25, 120, 69, 14);
		frame.getContentPane().add(lblNewLabel);
		//password label
		JLabel lblNewLabel_1 = new JLabel("Password:");
		lblNewLabel_1.setBounds(25, 170, 132, 14);
		frame.getContentPane().add(lblNewLabel_1);
		//passwordField
		passwordField = new JPasswordField();
		passwordField.setBounds(25, 195, 184, 21);
		frame.getContentPane().add(passwordField);
		//create account button
		JButton createAccBtn = new JButton("Create Account");
		 createAccBtn.addActionListener(new ActionListener() {
			 /**
			  * method that when the button is pressed validates the 
			  * password and username fields as well adds the person into 
			  * the file and creates and opens an account for them 
			  * Both Checking and Savings
			  */
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent event) {
				//local variables for name and password
				String pass = passwordField.getText();
				String firstName = firstNameField.getText();
				String lastName = lastNameField.getText();
				String license = LicenseField.getText();
			
				Map<String, String> has = Proxy.getHash();

				try {
					prox.readFile();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				
				int accountNumber= Integer.parseInt(license);
				Account savingsAccount = new SavingsAccount(accountNumber +1, BigDecimal.valueOf(0));//on button press a savings account is created
				Account checkingAccount = new CheckingAccount(accountNumber, BigDecimal.valueOf(0));//a checking account is also created
				Person person = new Person(firstName, lastName, license);
				prox.setHash(firstName, pass, person);
				bankingsystem.addPerson(person);
				bankingsystem.openAccount(person, checkingAccount);
				bankingsystem.openAccount(person, savingsAccount);
				
				try {
					prox.writeFileData(); // once the button is pressed the file is then written to for the database
					prox.writeFileCred(); // and the credentials text files
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//if else statments to check if the fields are empty or dont meet the requirements
				if (firstName.isEmpty()) {
					JOptionPane.showMessageDialog(frame, "Enter your firstname");
				}
				if (lastName.isEmpty()) {
					JOptionPane.showMessageDialog(frame, "Enter your lastname");
				}
				if (license.isEmpty()) {
					JOptionPane.showMessageDialog(frame, "Enter your license");
				}
				

				if (pass.isEmpty()) {
					JOptionPane.showMessageDialog(frame, "Password must contain a number and a capital letter");
				} else if (!pass.matches("[A-Za-z0-9]*")) {
					JOptionPane.showMessageDialog(frame, "Password must contain a number and a capital letter");

				} else if (pass.length() < 8) {
					JOptionPane.showMessageDialog(frame, "Password contain 8 letters and or numbers");
				} 
				else {
				//on creation of the account the frame closes
					frame.dispose();
				}
			}
		});
		 createAccBtn.setBounds(88, 227, 121, 23);
		frame.getContentPane().add( createAccBtn);
		
		LicenseField = new JTextField();
		LicenseField.setColumns(10);
		LicenseField.setBounds(25, 36, 184, 20);
		frame.getContentPane().add(LicenseField);
		
		JLabel lblLicense = new JLabel("License ");
		lblLicense.setBounds(25, 11, 46, 14);
		frame.getContentPane().add(lblLicense);
		
		JLabel lblFirstname = new JLabel("Firstname:");
		lblFirstname.setBounds(25, 67, 69, 14);
		frame.getContentPane().add(lblFirstname);
		
		firstNameField = new JTextField();
		firstNameField.setColumns(10);
		firstNameField.setBounds(25, 89, 184, 20);
		frame.getContentPane().add(firstNameField);

	}
	
}
