
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/*
 * author hackn1a
 * This code shows recursion using a brain teaser 
 * and a binary converter
 */
public class Main {

	public static void main(String[] args) throws IOException {
		// prints out the binary conversion
		integerToBinary(47);
		// adds a line to separate the two tests
		System.out.println("");
		// prints the recursive to cross the river
		Recursive.crossRiver(3);
		// try and catch to create a new file named output.txt
		File newFile = new File("output.txt");
		try {

			newFile.createNewFile();
		} catch (Exception e) {
			e.printStackTrace();
		}

		// creates a dataoutputstream and outputs it into an output.txt
		DataOutputStream outputFile = new DataOutputStream(new FileOutputStream("output.txt"));
		outputFile.close();
	}

	/**
	 * this method takes in @param n and converts it into a binary number then
	 * returns the number as @return bin
	 */
	public static String integerToBinary(int n) {
		int remainder = n % 2;
		String bin = "";
		bin = bin + remainder;
		n = n / 2;
		System.out.print(n);
		System.out.print(bin);
		if (n > 0) {

		}
		return bin;
	}
}