
public interface Recursive {

	/**
	 * this method takes in @param n from the main and sends it through and outputs
	 * in the counsel 
	 */
	public static void crossRiver(int n) {
		//create variables so that the right side can count up
		int soldiersRight = 0;
		int count = 0;
		//have an if statement to keep the recursion going until it reaches 0
		if (n > 0) {
			System.out.println("----------------------------------");

			System.out.println(n + " Soldiers " + "       ----> " + (soldiersRight) + " Soldiers, 2 boys");
			System.out.println(n + " Soldiers, 1 boy " + "<---- " + (soldiersRight) + " Soldiers, 1 boys");
			
			System.out.println((n - 1) + " Soldiers, 1 boy " + "----> " + (soldiersRight + (++count)) + " Soldiers, 1 boys");
			
			System.out.println((n - 1) + " Soldiers, 2 boy " + "<---- " + (soldiersRight + (++count )) + " Soldiers");
			System.out.println("----------------------------------");
			//have crossRiver subtract by 1 to keep it from infinitely recursing  
			crossRiver(n - 1);

		}

	}

}