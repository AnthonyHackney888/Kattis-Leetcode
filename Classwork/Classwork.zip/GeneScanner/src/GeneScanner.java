import java.io.IOException;
import java.util.Scanner;
import java.io.File;
/* 
 * 	  PID: H4
 *    Author: Anthony Hackney
 *    Date: 03/10/18
 *    
 *    Description: Practice reading in from a file
 */

public class GeneScanner {

	public static void main(String[] args) throws IOException {
		int A = 0;
		int T = 0;
		int C = 0;
		int G = 0;
		int totalGene;

		// Step 1 read in the file
		File f = new File("gene.txt");
		Scanner scanner = new Scanner(f);

		// Step 2 count the ATCG in the file
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			for (int i = 0; i < line.length(); i++) {
				if (line.charAt(i) == 'A') {
					A++;
				} else if (line.charAt(i) == 'T') {
					T++;
				} else if (line.charAt(i) == 'C') {
					C++;
				} else if (line.charAt(i) == 'G') {
					G++;
				}

			}

		}
		// Step 3 create a total for the genes
		totalGene = (A + T + C + G);
		// Step 4 print out the totals
		System.out.println("Stats for gene: >53794092|(BRCA1) mRNA");
		System.out.println("Nucleotide representation in this " + 
						   "gene by relative frequency.");
		System.out.println("Percent A: " + ((double) A / totalGene) * 100);
		System.out.println("Percent T: " + ((double) T / totalGene) * 100);
		System.out.println("Percent C: " + ((double) C / totalGene) * 100);
		System.out.println("Percent G: " + ((double) G / totalGene) * 100);
		
		scanner.close(); 
	}
}
