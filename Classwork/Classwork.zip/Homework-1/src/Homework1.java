
/*
     * PID: H1
     * Author: 	Anthony Hackney
	 * Date:   	01/18/18
	 *
	 * Description:  The calculation of the height of an object in feet.
	 */
import java.util.Scanner;

public class Homework1 {

	public static void main(String[] args) {

		double initialHeight = 0.0;
		double initialVelocity = 0.0;
		double time = 0.0;
		double finalHeight = 0.0;

		/* initial scanner */
		Scanner scanner = new Scanner(System.in);

		// Step 1 Enter the prompts on each new line //
		System.out.println("The initial height in feet: ");
		initialHeight = scanner.nextInt();
		System.out.println("The initial velocity in feet per "
				+ "second(s): ");
		initialVelocity = scanner.nextInt();
		System.out.println("The time the object spent in the "
				+ "air in seconds: ");
		time = scanner.nextInt();

		// Step 2 Calculate the final height//
		finalHeight = -16 * (Math.pow(time, 2)) + initialVelocity * 
				time + initialHeight;
		
		// Step 3
		System.out.println("The height of the object after " + time +
				" second(s) is " + finalHeight + " feet.");
		
		/* close scanner */
		scanner.close();

	}

}
