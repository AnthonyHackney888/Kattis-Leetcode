import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;


/*
 * @author hackn1a
 */
public class Main {

    public static void main(String[] args) throws FileNotFoundException, IOException { //throw file exceptions

        Map hashMap = new HashMap(); //create a hashmap

        try (BufferedReader buffRead = new BufferedReader(new FileReader("Odysseys.txt"))) {//Create a try and catch in the case there is an error and 
        	//create a buffered reader and file reader for the text file
            String Fileline = buffRead.readLine();
            //create a while loop to keep reading through the file
            while (Fileline != null) {
            	//create an array to put the words from the file into
            	
                String[] words = Fileline.split(" ");
                
                for (int i = 0; i < words.length; i++) {
                    if (hashMap.get(words[i]) == null) {
                        hashMap.put(words[i], 1);
                    } else {
                        int newVal = Integer.valueOf(String.valueOf(hashMap.get(words[i])));
                        newVal++;
                        hashMap.put(words[i], newVal);
                    }
                }
                
                Fileline = buffRead.readLine();
            }
        }
        
        Map<String, String> word = new TreeMap<String, String>(hashMap);
        for (String key : word.keySet()) { //use the Enhanced for loop
            System.out.println(hashMap.get(key) + " Count(s): " +key); //print out the word count and key
               }
    }
   
}
