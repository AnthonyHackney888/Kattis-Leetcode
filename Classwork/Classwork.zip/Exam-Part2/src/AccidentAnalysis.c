/*
 ============================================================================
 Name        : Exam-Part2.c
 Author      : Anthony hackney hackn1a
 Version     :
 Copyright   : Your copyright notice
 Description : This program takes in information from a file and outputs the
 accidents, fatals, and frequency
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {

//initilaize all the variables needed
	char fileName[] = "accidents.txt";
	int rows, columns;
	int morningCount, accidentMorningCount, fatalsMorningCount;
	int afternoonCount, accidentAfternoonCount, fatalsAfternoonCount;
	int nightCount, accidentNightCount, fatalsNightCount;
	double morningAverage, afternoonAverage, nightAverage;
	//open the file and make sure it is there
	FILE *filePointer;
	filePointer = fopen(fileName, "r");
	if (filePointer == NULL) {
		printf("File %s was not found.", fileName);
		exit(1);
	}
	//have a while loop to loop through the file and look for the rows
	//and columns
	while (fscanf(filePointer, "%d %d", &rows, &columns) != EOF) {
		int accidents[rows][columns];//initialize an array
		//create a nested forloop to parse through the array
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				//if statements to find the freqencey of the numbers
				if (accidents[i][0] >= 6 || accidents[i][0] <= 12) {
					morningCount = morningCount + 1;


				}
				if (accidents[i][0] >= 13 && accidents[i][0] <= 19) {
					afternoonCount++;

				}
				if ((accidents[i][0] >= 0 && accidents[i][0] <= 5)
						|| (accidents[i][0] >= 20 && accidents[i][0] <= 23)) {
					nightCount++;

				}

				if (accidents[i][1] >= 6 && accidents[i][1] <= 12) {
					accidentMorningCount++;

				}
				if (accidents[i][1] >= 13 && accidents[i][1] <= 19) {
					accidentAfternoonCount++;

				}
				if ((accidents[i][1] >= 0 && accidents[i][1] <= 5)
						|| (accidents[i][1] >= 20 && accidents[i][1] <= 23)) {
					accidentNightCount++;

				}

				if (accidents[i][2] >= 6 && accidents[i][2] <= 12) {
					fatalsMorningCount++;

				}
				if (accidents[i][2] >= 13 && accidents[i][2] <= 19) {
					fatalsAfternoonCount++;

				}
				if ((accidents[i][2] >= 0 && accidents[i][2] <= 5)
						|| (accidents[i][2] >= 20 && accidents[i][2] <= 23)) {
					fatalsNightCount++;

				}

			}

		}

	}
	//calculate the averages
	morningAverage = accidentMorningCount / morningCount;
	afternoonAverage = accidentAfternoonCount / afternoonCount;
	nightAverage = accidentNightCount / nightCount;
	//attempt to copy the format
	printf("Time Span   ");
	printf("  Accidents");
	printf("  Vehicles  ");
	printf("  Fatals  ");
	printf("  Veh./Acc.\n");
	printf("----------------------------------------------------\n");
	//print the morning, afternoon, and nights counts
	printf("Morning      %d   %d   %d   %lf\n", morningCount,
			accidentMorningCount, fatalsMorningCount, morningAverage);
	printf("Afternoon    %d   %d   %d   %lf\n", afternoonCount,
			accidentAfternoonCount, fatalsAfternoonCount, afternoonAverage);
	printf("Night        %d   %d   %d        %lf\n", nightCount,
			accidentNightCount, fatalsNightCount, nightAverage);

	printf("----------------------------------------------------");

	return EXIT_SUCCESS;
}

