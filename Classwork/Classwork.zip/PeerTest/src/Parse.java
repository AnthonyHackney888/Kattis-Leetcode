/*
 * Hunter francek
 * cps210
 * class to parse and strip comments from instruction
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.*;

public class Parse {
		BufferedReader file;
		int currentLine=0;
		Sym st=new Sym();
	
	
	public Parse(Path pathIn) {
		
		Path absolutePath=pathIn.toAbsolutePath();
		try {
			this.file = Files.newBufferedReader(absolutePath);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public enum CommandNames {
	    A_COMMAND, L_COMMAND, C_COMMAND, END 
	}
	
	String stringy(){
		
		String stline;
		
		try {
			if ((stline = file.readLine()) != null) {
			    stline=stline.trim();
		    if (stline.equals("")||stline.charAt(0)=='/'){
		    	return stringy();
		    }
		    else{
		    	if (stline.contains("//")){
		    		currentLine++;
		    		return stline.substring(0, stline.indexOf('/'));			    		
		    	}
		    	else{
		    		if (!(commandType(stline)==CommandNames.L_COMMAND))
		    			currentLine++;
		    		return stline;
		    	}
		    }
		}
			else{
				return "END";
			}
		} catch (IOException x) {
			x.printStackTrace();
			return "END";
		}
		
	}
	
	CommandNames commandType(String rawLine){
		
		if (rawLine.charAt(0)=='@'){
			return CommandNames.A_COMMAND;
		}
		else if(rawLine.charAt(0)=='('){
			return CommandNames.L_COMMAND;
		}
		else if(rawLine.equals("END")){
			return CommandNames.END;
		}
		else{
			return CommandNames.C_COMMAND;
		}
	}
	
	//strips symbols
	String bol(String com){
		//A Commands
		if (com.charAt(0)=='@'){
			if ((com.charAt(1)>='0')&&(com.charAt(1)<='9'))
				return com.substring(1);
			//symbols
			else{
				if (st.contains(com.substring(1)))
					return st.getAddress(com.substring(1));
				else
					return st.moresym(com.substring(1));
			}
		}
		else{
			st.moresym(com.substring(1,com.length()-1), currentLine);
			return "skip";
		}
	}
	
	//c
	String dest(String com){
		if (com.contains("=")){
			return com.substring(0, com.indexOf('='));
		}
		else{
			return "null";
		}
	}
	String jump(String com){
		if (com.contains(";")){
			return com.substring(com.indexOf(';')+1,com.length());
		}
		else{
			return "null";
		}
	}
	String comp(String com){
		if (com.contains("=")){
			if (com.contains(";")){
				return com.substring(com.indexOf('=')+1, com.indexOf(';'));
			}
			else{
				return com.substring(com.indexOf('=')+1, com.length());
			}
		}
		else{
			if (com.contains(";")){
				return com.substring(0, com.indexOf(';'));
			}
			else{
				return com;
			}
		}
	}
	

}