import java.io.*;
import java.util.*;

public class Assembler {

	static ArrayList<String> rom = new ArrayList<String>();
	ArrayList<String> symTable = new ArrayList<String>();
	ArrayList<String> compTable = new ArrayList<String>();
	ArrayList<String> destTable = new ArrayList<String>();
	ArrayList<String> jumpTable = new ArrayList<String>();
	ArrayList<String> label = new ArrayList<String>();
	ArrayList<String> values = new ArrayList<String>();
	ArrayList<String> binary = new ArrayList<String>();
	String fileN = "";

	public Assembler(String fileName) throws FileNotFoundException {
		// Declaring variables to hold the instructions and the labels
		fileN = fileName;
		String line = "";
		String pureIns = "";
		String labelHold = "", labelH = "";
		int x = 0, j = 16;

		try {
			File file = new File(fileName);
			FileReader fr = new FileReader(file);
		}catch(FileNotFoundException e) {
			System.out.println("File not found");
		}
		
		// used to read the file
		File file = new File(fileName);
		Scanner scan = new Scanner(file);

		// Loops through the file until there are no more lines
		while (scan.hasNextLine()) {
			// uses variable to make the code easier to understand
			line = scan.nextLine();

			// Loop to go through the line character by character
			for (int i = 0; i < line.length(); i++) {

				// if char is /, then break out of loop because it is a comment
				if (line.substring(i, i + 1).equals("/")) {
					break;
				}
				// checks to see if line is a label
				else if (line.charAt(i) == '(') {

					// loops through line until either line ends or comment is reached
					for (int y = 0; y < line.length(); y++) {
						if (line.charAt(y) == '/') {
							break;
						} else {
							labelHold = labelHold + line.charAt(y);
						}
					}
					// breaks out of for loop so loop doesn't add label
					// to pure instructions
					break;

				} else {
					pureIns = pureIns + line.charAt(i);
				}
			}

			//checks to see if the line was a label or not
			if (!labelHold.equals("")) {
				for (int i = 0; i < labelHold.length(); i++) {
					if (labelHold.charAt(i) != '(' && labelHold.charAt(i) != ')') {
						//adds label name without the parentheses
						labelH = labelH + labelHold.charAt(i);
					}

				}
				//adds the value to the label to be put in the table
				labelH = labelH + " " + x;
				
				// adds labels to their own arrayList
				label.add(labelH);
				labelH = "";
			}

			// adds instructions to the rom arrayList
			if (!pureIns.equals("")) {
				rom.add(pureIns);
				x++;
			}
			// resets the hold variables
			labelHold = "";
			pureIns = "";
		}
		scan.close();
	}

	//loops through the instructions again, converting the a-instructions to their integer values,
	//and converting the c-instructions into the binary values for them
	public void secondPass() {
		String insHold = "", symName = "", tableHold = "", tableName = "", tableVal = "", hold = "";
		String dest = "", comp = "", jump = "", bin = "111", holder = "", subHold = "";
		int symVal = 16;

		// Loops through the rom arralysit to get the
		// pure A-instructions
		for (int i = 0; i < rom.size(); i++) {
			insHold = rom.get(i);

			// Loops through the string character by character
			// to either get the symbol name or determine if it is
			// an A-instruction
			for (int y = 1; y < insHold.length(); y++) {

				// if the line starts with an @ (a-instruction), then it scans in the
				// symbol name, otherwise it exits the loop
				if (insHold.charAt(0) == '@') {
					//searches for space because that is when the symbol name ends
					if (insHold.charAt(y) == ' ') {
						break;
					} else {
						symName = symName + insHold.charAt(y);
					}
					// otherwise, gets what is necessary for the c instruction
				}

			}

			// Loops through ins line character by character
			// to either get the comp portion, jump portion, or dest portion
			if (insHold.charAt(0) != '@') {
				for (int z = 0; z < insHold.length(); z++) {

					//if there is an equals sign, then the comp becomes the substring after the equals sign
					if (insHold.charAt(z) == '=') {
						comp = insHold.substring(z + 1, insHold.length());
						break;
						//if there is a semi-colon, the jump variable becomes the substring after the semi-colon
					} else if (insHold.charAt(z) == ';') {
						jump = insHold.substring(z + 1, insHold.length());
						//what was the destination becomes the comp
						comp = dest;
						//the dest is set to null
						dest = "";
						break;
						//otherwise the character is added to the destination variable
					} else {
						dest = dest + insHold.charAt(z);
					}

				}
			}

			// checks to see if the symbol name is empty or if the comp variable is empty(if c-instruction, there is always
			//a comp value), if it isn't then it loops through the symbol name
			if (!symName.equals("") || !comp.equals("")) {
				String sVal = "" + symVal;
				if (!symName.equals("")) {
					for (int x = 0; x < symTable.size(); x++) {
						tableHold = symTable.get(x);

						// loops through symbolTable line, adds characters to the tableName holder
						// until the space, which is when the symbol name in the table stops,and adds
						// value
						// to the tableValue variable if after the space
						for (int z = 0; z < tableHold.length(); z++) {

							// if the character at z is a space, and z+1 is the same as the length of the
							// line, then break out of the loop, otherwise add the substring containing the value
							//to the tableVal variable
							if (tableHold.charAt(z) == ' ') {
								
								//if z + 1 is at the end of the line, then break out of the loop
								if (z + 1 == tableHold.length()) {

									break;

								} else {

									tableVal = tableHold.substring(z + 1, tableHold.length());
									break;

								}
								// otherwise, add to the tableName variable
							} else {

								tableName = tableName + tableHold.charAt(z);

							}
							// checks to see if the symbolName is equal to any name in the table,
							// and if it does then it adds the value of it to a value table needed
						}
						// holds the tableName for after the loop
						hold = tableName;

						// checks to see if the symbol name is already a spot in the RAM, if it is
						// then it adds it to the table with itself as the value because the value has a designated RAM
						//spot at its name (i.e. 78 has RAM spot 78)
						if (symName.startsWith("1") || symName.startsWith("2") || symName.startsWith("3")
								|| symName.startsWith("4") || symName.startsWith("5") || symName.startsWith("6")
								|| symName.startsWith("7") || symName.startsWith("8") || symName.startsWith("9") || symName.startsWith("0")) {
							symTable.add(symName + " " + symName);
							values.add(symName);
							hold = symName;
							break;
						}
						//If the symbol name is in the table/equals the current table name,
						//then it takes adds the value from the table to the arraylist of values
						if (symName.equals(tableName)) {
							values.add(tableVal);
							break;
						}
						// resets values of tableName if symbol name wasn't in table
						tableName = "";
					}
					// if the symbol name wasn't in the table, it adds it to the table, as well as
					// the value and then adds that value to the value table
					if (!symName.equals(hold)) {
						symTable.add(symName + " " + symVal);
						values.add(sVal);
						symVal++;
					}

					// resets value of table information
					tableHold = "";
					tableName = "";

				}

				// checks to see if the line is c instruction or not
				if (!comp.equals("")) {
					// finds the correct match within the comp table
					for (int j = 0; j < compTable.size(); j++) {

						//holds the entire line from the table
						holder = compTable.get(j);

						//loops through the line and gets just the symbol
						//looks for a space, because that is where the symbol/name ends and the binary
						//value begins
						for (int b = 0; b < holder.length(); b++) {
							if (holder.charAt(b) == ' ') {
								break;
							} else {
								subHold = subHold + holder.charAt(b);
							}
						}
						// if the two match, it adds the correct binary sequence to the binary string
						if (comp.equals(subHold)) {
							for (int a = 0; a < holder.length(); a++) {
								if (holder.charAt(a) == ' ') {
									//adds the binary substring to the binary value by searching for a space and adding
									//the substring that goes from the spot after the space to the end of the line
									bin = bin + holder.substring(a + 1, compTable.get(j).length());
									subHold = "";
									break;
								}
							}
							break;
						}
						//resets the value taken from the table to blank
						subHold = "";
					}

					// finds the correct match within the destination table
					for (int j = 0; j < destTable.size(); j++) {

						//if there is no destination, it is set to null
						if (dest == "") {
							dest = "null";
						}
						//holds the line from the destination table
						holder = destTable.get(j);

						//loops through the line to get only the symbol/name
						//looks for a space, because that is where the symbol/name ends and the binary
						//value begins
						for (int b = 0; b < holder.length(); b++) {
							if (holder.charAt(b) == ' ') {
								break;
							} else {
								subHold = subHold + holder.charAt(b);
							}
						}
						// if the destination matches, then adds the correct binary code to the string
						if (dest.equals(subHold)) {
							for (int a = 0; a < holder.length(); a++) {
								if (holder.charAt(a) == ' ') {
									//adds the binary substring to the binary value by searching for a space and adding
									//the substring that goes from the spot after the space to the end of the line
									bin = bin + holder.substring(a + 1, destTable.get(j).length());
									subHold = "";
									break;
								}
							}
							break;
						}
						subHold = "";
					}
					
					// finds the correct match within the jump table
					for (int j = 0; j < jumpTable.size(); j++) {

						//checks to see if the jump portion is empty
						//if it is, then the variable gets set to "null"
						if (jump == "") {
							jump = "null";
						}
						//holds the line from the jump table
						holder = jumpTable.get(j);

						//loops through the line being help to get only the symbol/name
						//looks for a space, because that is where the symbol/name ends and the binary
						//value begins
						for (int b = 0; b < holder.length(); b++) {
							if (holder.charAt(b) == ' ') {
								break;
							} else {
								subHold = subHold + holder.charAt(b);
							}
						}
						// if the jump matches, then adds the correct binary code to the string
						if (jump.equals(subHold)) {
							for (int a = 0; a < holder.length(); a++) {
								if (holder.charAt(a) == ' ') {
									//adds the binary substring to the binary value by searching for a space and adding
									//the substring that goes from the spot after the space to the end of the line
									bin = bin + holder.substring(a + 1, jumpTable.get(j).length());
									subHold = "";
									break;
								}
							}
							break;
						}
						subHold = "";
					}
					values.add(bin);
				}

			}
			// resets the symbol information
			symName = "";
			insHold = "";
			// resets c-ins info
			dest = "";
			comp = "";
			jump = "";
			bin = "111";

		}
	}

	// used to convert the values that aren't already
	// in binary into binary
	public void sToIConvert() {
		ArrayList<Integer> ints = new ArrayList<Integer>();
		int holder = 0, extra = 0, f = 0;
		String bin = "", fullBin = "";

		// changes the string values into integers to convert
		for (int i = 0; i < values.size(); i++) {
			if (values.get(i).length() < 16) {
				ints.add(Integer.parseInt(values.get(i)));
			}

		}

		// loop to convert each int into a binary string
		for (int x = 0; x < ints.size(); x++) {
			holder = ints.get(x);

			while (holder > 0) {
				extra = holder % 2;
				bin = extra + "" + bin;
				holder = holder / 2;
			}
			// adds the binary string to the arraylist, resets
			// the local variables

			binary.add(bin);
			bin = "";
			holder = 0;
			extra = 0;
		}

		// adds zeros to the a-instruction binary until it is 16-bit
		for (int i = 0; i < binary.size(); i++) {
			fullBin = binary.get(i);
			while (fullBin.length() < 16) {
				fullBin = "0" + fullBin;
			}
			// replaces the value in the current spot with the completed binary
			binary.remove(i);
			binary.add(i, fullBin);
		}

		// loops through the values arraylist
		for (int i = 0; i < values.size(); i++) {
			// as long as the variable is less than the desired binary
			if (values.get(i).length() < 16) {
				//removes the integer value and replaces it with the integer converted to binary
				values.remove(values.get(i));
				values.add(i, binary.get(f));
				f++;
			}
		}

	}

	// inserts the pre-defined symbol table
	// as well as adds the labels to the table
	public void symbolTable() throws Exception {

		// used to scan file in
		File file = new File("symbols.txt");
		Scanner scan = new Scanner(file);

		// scans in table and adds them to their
		// own arraylist
		while (scan.hasNextLine()) {
			symTable.add(scan.nextLine());
		}

		// adds labels to symbol table
		for (int y = 0; y < label.size(); y++) {
			symTable.add(label.get(y));
		}

		scan.close();

	}

	// puts info from comp Table file into arraylist
	public void compTable() throws Exception {

		File file = new File("comp.txt");
		Scanner scan = new Scanner(file);

		// scans lines of table into arraylist
		while (scan.hasNextLine()) {
			compTable.add(scan.nextLine());
		}
		scan.close();
	}

	// puts info from dest table file into arraylist
	public void destTable() throws Exception {

		File file = new File("dest.txt");
		Scanner scan = new Scanner(file);

		// scans lines of table into an arraylist
		while (scan.hasNextLine()) {
			destTable.add(scan.nextLine());
		}
		scan.close();
	}

	// puts info from jump table file into arraylist
	public void jumpTable() throws Exception {
		File file = new File("jump.txt");
		Scanner scan = new Scanner(file);

		// scans lines of table into arraylist
		while (scan.hasNextLine()) {
			jumpTable.add(scan.nextLine());
		}
		scan.close();
	}

	// prints the instructions line by line
	public void printROM() {
		for (int i = 0; i < rom.size(); i++) {
			System.out.println(rom.get(i));
		}
	}

	// able to print tables whenver desired
	public void printTables() {
		// prints out symbol table
		for (int i = symTable.size() - 1; i >= 0; i--) {
			System.out.println(symTable.get(i));
		}

		System.out.println("");

		// prints out comp table
		for (int x = 0; x < compTable.size(); x++) {
			System.out.println(compTable.get(x));
		}

		System.out.println("");

		// prints out dest table
		for (int y = 0; y < destTable.size(); y++) {
			System.out.println(destTable.get(y));
		}

		System.out.println();

		// prints out jump table
		for (int z = 0; z < jumpTable.size(); z++) {
			System.out.println(jumpTable.get(z));
		}
	}

	// prints out the values from the symbol table that are used in the asm file
	public void printVals() {
		for (int i = 0; i < values.size(); i++) {
			System.out.println(values.get(i));
		}
	}

	// prints values converted to binary
	public void printBin() {
		for (int i = 0; i < binary.size(); i++) {
			System.out.println(binary.get(i));
		}
	}

	// writes the binary output values into a .hack file
	public String writeOutput() throws IOException {

		String name = fileN, newName = "";

		// gets the name of the file, to make sure it uses the same name
		// with .hack
		for (int i = 0; i < name.length(); i++) {
			if (name.charAt(i) == '.') {
				break;
			} else {
				newName = newName + name.charAt(i);
			}
		}

		// creates the file with the name and .hack
		// then writes the arraylist with the output to the file
		FileWriter writer = new FileWriter(newName + ".hack");
		for(int i = 0; i < values.size(); i++) {
			writer.write(values.get(i) + System.getProperty("line.separator"));
		}
		writer.close();
		return "The output file has been finished";
		
	}
}
