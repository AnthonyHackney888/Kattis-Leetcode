import java.util.Scanner;

//Program written by: Jordan Kohler

//Description: This program asks the user to type the input of a file
//then, if the file is found, it converts the assembly language
//code into binary through a large series of steps

//Problems encountered: Most of the problems that i encountered
//while programming this occurred when coding the secondPass method.
//One problem that I faced was making sure that I could get the correct value
//for the symbol if it was included or if it wasn't on the table, but I worked
//around that by looping through the line, and setting a holder variable to the
//correct value. The main problem that I faced was just keeping track of all of the
//code that is in the second pass method to make sure that all of the lines are converted
//properly.

//Modular Description: The entire program, except for the creation of the variable and call
//of the necessary methods all are within the Assembler class.

public class Main {

	public static void main(String[] args) throws Exception {

		Scanner scan = new Scanner(System.in);

		System.out.println("Input a file name");
		String file = scan.next();

		//creates assembler with input file name
		Assembler assembler = new Assembler(file);
		//creates the different tables and then prints them out
		assembler.symbolTable();
		assembler.compTable();
		assembler.destTable();
		assembler.jumpTable();
		assembler.printTables();
		
		//performs the second pass to get the lines into either integers (a-instruction) or binary (c-instruction)
		assembler.secondPass();
		
		//converts the a-instruction integers to bianry
		assembler.sToIConvert();
		
		//prints out the converted values
		assembler.printVals();
		
		//performs the writing to a .hack output file, prints out statement when done
		System.out.println(assembler.writeOutput());
	}

}
