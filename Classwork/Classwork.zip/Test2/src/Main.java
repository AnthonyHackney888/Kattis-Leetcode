import java.io.IOException;
import java.io.FileInputStream;
import java.util.Scanner;
import java.io.File;

public class Main {

	public static void main(String[] args) throws IOException {
		Scanner scnr = new Scanner(System.in);
		String userInput ="";
		System.out.println("Enter file name");
		userInput = scnr.nextLine();
		File file = new File(userInput);
		Scanner scanFile = new Scanner(file);
		int linesCount = 0;
		int charCount = 0;
		int wordsCount = 0;
		System.out.println("Here are the stats for " +userInput);
		
		while (scanFile.hasNextLine()) {

			linesCount++;
			String line = scanFile.nextLine();
			Scanner lineScanner = new Scanner(line);
			for( int i = 0; i<line.length();i++) {
				charCount++;
			}
		
		
		while (lineScanner.hasNext()) {
			wordsCount++;
			String word = lineScanner.next();
		}
	
	}
		System.out.println("Number of lines: " +linesCount);
		System.out.println("Character count: " +charCount);
		System.out.println("Word count: " +wordsCount);
}
}