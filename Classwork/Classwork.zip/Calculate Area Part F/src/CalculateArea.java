import java.util.Scanner;
/*
 * PID: IC1
 * Author: 	Group16
 * Date:   	01/22/18
 *
 * Description:  Calculate the area of a circle
 */

public class CalculateArea {

	public static void main(String[] args) {
	
		double circleArea;
		double circleCircumference;
		double pi = 3.14;
		double circleRadius;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter the radius of a circle");
		radius = scanner.nextDouble();
		
		circleArea = pi * circleRadius *
		
		System.out.print("The area of a circle with radius " + radius);
		System.out.println("is" + cirlcearea);
		System.out.print("The circumfrence of this circle is ");
              System.out.println(circlecircumfrence);
		
		return;

	}
}