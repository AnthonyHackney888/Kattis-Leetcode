/*
 * PID: H6
 * Author: Anthony Hackney
 * Date:   	04/06/18
 *
 * Description: Finding the average, median, and range of the given exams scores 
 * as arrays. Using multiple methods to calculate the 
 * average, median, and range.
 */

public class MathLibs {

	public static void main(String[] args) {

		double[] exam1Scores = { 100.0, 59.0, 37.5, 85.3, 97.0, 75.0, 77.7, 37.0, 95.0 };
		double[] exam2Scores = { 10.0, 20.0, 30.0, 40.0, 50.0 };

		System.out.println("Stats for exam 1...");
		System.out.printf("Avg: %4.2f\n", average(exam1Scores));
		// System.out.printf("Standard Deviation: %4.2f\n", stdDeviation(exam1Scores);
		System.out.printf("Median: %4.2f\n", median(exam1Scores));
		System.out.printf("Range: %4.2f\n", range(exam1Scores));

		System.out.println("\nStats for exam 2...");
		System.out.printf("Avg: %4.2f\n", average(exam2Scores));
		// System.out.printf("Standard Deviation: %4.2f\n", stdDeviation(exam2Scores);
		System.out.printf("Median: %4.2f\n", median(exam2Scores));
		System.out.printf("Range: %4.2f\n", range(exam2Scores));

	}

	/*************************************************************
	 * median - Determine the median of the two exam scores. The median is middle
	 * most value of a sort list of values. If there is an even number of values
	 * then the average of the two middle most values should be returned. double[]
	 * data - an array of data, that may or may not be sorted
	 */
	public static double median(double[] data) {
		// Step 1 intialize the integers
		// and sort the array
		double medianExams = 0.0;
		double tempVar = 0.0;
		for (int i = 0; i < data.length - 1; i++) {
			for (int j = 0; j < data.length - 1; j++) {
				if (data[i] > data[j]) {
					tempVar = data[j];
					data[j] = data[i];
					data[i] = tempVar;
				}
				// Step 2 find teh median of the array
				// because one of them results in two in the middle
				// add them together and divide by two
				if (data.length % 2 == 0) {
					medianExams = ((double) data[i / 2] + (double) data[i / 2 - 1]) / 2;
				} else {
					medianExams = (double) data[i / 2];
				}

			}

		}
		return medianExams;

	}

	/**************************************************************************
	 * average - calculates the average of the two exam scores. The average is the
	 * sum of all of the values then divided by the number of values given.
	 * 
	 * double[] data - an array of data, that may or may not be sorted
	 */
	public static double average(double[] data) {
		// Step 3 intialize two doubles to calculate the sum of the array
		// and then calculate the averages in the exams scores
		double averageExams = 0.0;
		double sum = 0.0;
		for (int i = 0; i < data.length; i++) {
			sum = sum + data[i];
			averageExams = sum / data.length;
		}

		return averageExams;
	}

	/**************************************************************************
	 * range - finds the range of the two exam scores. The range is the difference
	 * of value between the largest and smallest of values given
	 * 
	 * double[] data - an array of data, that may or may not be sorted
	 */
	public static double range(double[] data) {
		// Step 4 intialize the variables
		double rangeExams = 0.0;
		double maxValue = data[0];
		double minValue = data[0];
		double tempVar = 0.0;
		// Step 5 sort the arrays using a temp variable
		for (int i = 0; i < data.length - 1; i++) {
			for (int j = i + 1; j < data.length; j++) {
				if (data[i] > data[j]) {
					tempVar = data[j];
					data[j] = data[i];
					data[i] = tempVar;
					// Step 6 find the maximum and minimum
					// in the sorted arrays
					if (data[i] > maxValue) {
						maxValue = data[i];
					}
					if (data[i] < minValue) {
						minValue = data[i];

					}

				}
				// Step 7 find the difference in values and return
				rangeExams = (maxValue - minValue);

			}
		}
		return rangeExams;
	}

	// [OPTIONAL!!!] YOUR HEADER HERE
	public static double stdDeviation(double[] data) {
		// OPTIONAL!!! YOUR CODE HERE TO DETERMINE THE
		// STANDARD DEVIATION
		return 0;
	}

	/*************************************************************
	 * printArray - Print out all of elements from an array. The elements are
	 * displayed on one line followed by a new line character.
	 *
	 * double[] data - the array from which the data will be printed
	 */
	public static void printArray(float[] data) {
		for (int i = 0; i < data.length; i++) {
			System.out.print(data[i] + " ");
		}
		System.out.println();
	}

	/*************************************************************
	 * sort - Sorts the contents of the array using a selection sort procedure.
	 *
	 * double[] data - the array to be sorted. The contents of the array will be
	 * modified such that it is in ascending order
	 */
	public static void sort(double[] data) {

		// Idea: Start at the beginning of the array and search for the smallest
		// remaining value to swap down.
		for (int i = 0; i < data.length - 1; i++) {
			int idxOfSmallest = i;
			// Find the location of the smallest, remaining value
			for (int j = i; j < data.length; j++) {
				if (data[j] < data[idxOfSmallest]) {
					idxOfSmallest = j;
				}
			}

			// Swap the smallest, remaining value with position i.
			double temp = data[i];
			data[i] = data[idxOfSmallest];
			data[idxOfSmallest] = temp;
		}
	}

}