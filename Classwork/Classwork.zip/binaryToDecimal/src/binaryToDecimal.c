/*
 ============================================================================
 Name        : binaryToDecimal.c
 Author      : hackn1a
 Version     :
 Copyright   : Your copyright notice
 Description : converts from binary to decimal
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main(void) {
	char binStr[] = "00011001";
	int val = binaryToDecimal(binStr, strlen(binStr));
	printf("%d", val);
	return EXIT_SUCCESS;
}
/**
 * Method to convert the binary to decimal
 */
void binaryToDecimal(char binStr[]) {

	int n = 0;//initialize a variable to hold the converted number
	//for loop to parse through the array
	for (int i = sizeof(binStr[i]); i > 0; i--) {
		//set every 1 in the array and aonver it
		if (binStr[i] == '1') {
			n = pow(2, i)+n;
		}
	}

}
