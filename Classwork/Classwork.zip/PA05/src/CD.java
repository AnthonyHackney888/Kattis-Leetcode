/*
 * author hackn1a
 * the CD class compares itself
 */
public class CD implements Comparable<CD> {

	private long serialNumber; //since a serial number can have letters use long
	private double price;
	private String title;
	private String artist;

	/*
	 * gets the orice of the CD
	 */
	public double getPrice() {
		return price;
	}
	//sets the price of the CD
	public void setPrice(double price) {
		this.price = price;
	}

	public String getName() {
		return title;
	}

	public void setName(String name) {
		this.title = name;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public CD(long serialNumber, double price, String name, String artist) {

		this.serialNumber = serialNumber;
		this.price = price;
		this.title = name;
		this.artist = artist;
	}

	public CD(long serialNumber) {

		this.serialNumber = serialNumber;
	}

	public long getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(long serialNumber) {
		this.serialNumber = serialNumber;
	}

	public CD() {

	}

	public String toString() {
		return "CD serialNumber =" + serialNumber + ", price = " + price + ", title = " + title + ", artist = "
				+ artist;
	}
	/*
	 * This method compares they CD objects
	 * while forcing them into an int so that they can be compared
	 */
	public int compareTo(CD o) {

		return (int) (this.serialNumber - o.serialNumber);
	}

}
