import java.util.ArrayList;

public class MergeSort {
	public static <E extends Comparable> void merge(ArrayList <E> numbers, int i, int j, int k) {
		int mergedSize = k - i + 1; // Size of merged partition
		ArrayList<E> mergedNumbers = new ArrayList<>(mergedSize);// Temporary array for merged numbers
		int mergePos = 0; // Position to insert merged number
		int leftPos = 0; // Position of elements in left partition
		int rightPos = 0; // Position of elements in right partition

		leftPos = i; // Initialize left partition position
		rightPos = j + 1; // Initialize right partition position

		// Add smallest element from left or right partition to merged numbers
		while (leftPos <= j && rightPos <= k) {
			if (numbers.get(leftPos).compareTo(numbers.get(rightPos))<0) {
				mergedNumbers.set(mergePos, numbers.get(leftPos));
				++leftPos;
			} else {
				mergedNumbers.set(mergePos, null);
				++rightPos;
			}
			++mergePos;
		}

		// If left partition is not empty, add remaining elements to merged numbers
		while (leftPos <= j) {
			mergedNumbers.set(mergePos, numbers.get(leftPos));
			++leftPos;
			++mergePos;
		}

		// If right partition is not empty, add remaining elements to merged numbers
		while (rightPos <= k) {
			mergedNumbers.set(mergePos, numbers.get(rightPos));
			++rightPos;
			++mergePos;
		}

		// Copy merge number back to numbers
		for (mergePos = 0; mergePos < mergedSize; ++mergePos) {
			numbers.get(mergePos).compareTo(mergedNumbers.get(mergePos));
		}
	}

	public static <E extends Comparable> void mergesort(ArrayList <E> numbers, int i, int k) {
		int j = 0;

		if (i < k) {
			j = (i + k) / 2; // Find the midpoint in the partition

			// Recursively sort left and right partitions
			mergesort(numbers, i, j);
			mergesort(numbers, j + 1, k);

			// Merge left and right partition in sorted order
			merge(numbers, i, j, k);
		}
	}

}
