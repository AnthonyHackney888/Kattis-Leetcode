
import java.util.ArrayList;
import java.util.Random;
/*
 * author hackn1a
 * 
 */
public class Main {
	static Random randomGenerator = new Random();
	static int ITEMS = 1000;
	
	public static void main(String[] args) {

		ArrayList<CD> numbers = new ArrayList<>(ITEMS); //An array list to hold the cd objects
		
		//created 4 different cd objects to test the code with not
		//very original names
		CD cd1 = new CD(15790, 100.00, "cd1", "cd1");
		CD cd2 = new CD(18786, 85.00, "cd2", "cd2");
		CD cd3 = new CD(19747, 5.00, "cd3", "cd3");
		CD cd4 = new CD(3000, 78.00, "cd4", "cd4");

		//added all four objects into the arrayList
		numbers.add(cd1);
		numbers.add(cd2);
		numbers.add(cd3);
		numbers.add(cd4);
		
		//have a binary and linear search for two different cd objects
		System.out.println("binary search of cd3: " + Searching.binarySearch(numbers, cd3));
		System.out.println("linear search of cd1: " + Searching.linearSearch(numbers, cd4));
		
		//have one Sorting method not commented so that only one will run at a time
		//SelectionSort is the first and only one uncommented 
		
		Sorting.selectionSort(numbers);
		//The sorting methods below still work they are commented out so that they
		//do not interfere with each other
		
		//Sorting.mergeSort(numbers);
		//Sorting.insertionSort(numbers);
		//Sorting.quickSort(numbers);
		
		//an enhanced for loop that prints out the cds toString
		for(CD cd : numbers ) {
			System.out.println(cd.toString());
			
		}
		//the two searches are used again to find the two different cds after they are sorted
		System.out.println("binary search of cd3: " + Searching.binarySearch(numbers, cd4));
		System.out.println("linear search of cd1: " + Searching.linearSearch(numbers, cd1));
		
		System.out.println();
		
		
	}

}
