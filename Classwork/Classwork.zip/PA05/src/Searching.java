import java.util.ArrayList;

public class Searching {
	public static final long serialNumber = 0;

	public static <E extends Comparable> int linearSearch(ArrayList<E> numbers, E key) {
		int i = 0;
		for (i = 0; i < numbers.size(); ++i) {
			if (numbers.get(i).equals(key)) {
				return i; /* position */
			}
		}
		return -1; /* not found */
	}

	public static<E extends Comparable> int binarySearch(ArrayList<E> numbers, E key) {
		int mid = 0;
		int low = 0;
		int high = 0;

		high = numbers.size() - 1;

		while (high >= low) {
			mid = (high + low) / 2;
			if (numbers.get(mid).compareTo(key) < 0) {
				low = mid + 1;
			} else if (numbers.get(mid).compareTo(key)>0) {
				high = mid - 1;
			} else {
				return mid;
			}
		}
		return -1; // not found
	}
}
