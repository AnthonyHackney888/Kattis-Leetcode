import java.util.ArrayList;

public class Sorting {
	public static <E extends Comparable> void selectionSort(ArrayList <E> numbers) {
	      int i = 0;
	      int j = 0;
	      int indexSmallest = 0;
	      E temp;  // Temporary variable for swap

	      for (i = 0; i < numbers.size(); ++i) {

	         // Find index of smallest remaining element
	         indexSmallest = i;
	         for (j = i + 1; j < numbers.size(); ++j) {

	            if (numbers.get(indexSmallest).compareTo(numbers.get(j))<0) {
	               indexSmallest = j;
	            }
	         }

	         // Swap numbers[i] and numbers[indexSmallest]
	         temp = numbers.get(i);
	         numbers.set(i, numbers.get(indexSmallest));
	         numbers.set(indexSmallest, temp);
	      }
	   }
	   
	   public static <E extends Comparable> void insertionSort(ArrayList <E> numbers) {
	      int i = 0;
	      int j = 0;
	      E temp;  // Temporary variable for swap

	      for (i = 1; i < numbers.size(); ++i) {
	         j = i;
	         // Insert numbers[i] into sorted part 
	         // stopping once numbers[i] in correct position
	         while (j > 0 && numbers.get(j).compareTo(numbers.get(j-1))<0) {

	            // Swap numbers[j] and numbers[j - 1]
	            temp = numbers.get(j);
	            numbers.set(j, numbers.get(j-1));
	            numbers.set(j-1, temp);
	            --j;
	         }
	      }
	   }
	
	public static <E extends Comparable> void mergeSort(ArrayList <E> numbers) {
		MergeSort.mergesort(numbers, 0, numbers.size() - 1);
	}
	
	
	public static <E extends Comparable> void quickSort(ArrayList <E> numbers) {
		QuickSort.quicksort(numbers, 0, numbers.size() - 1);
	}
	
	
}
