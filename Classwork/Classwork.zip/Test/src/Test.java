import java.util.Random;

public class Test  {

    private static Random random;

    public static void main(String[] args) {

        // Create object of class (initializes the
        // random generator with a default seed)
        random = new Random();

        String[] strArr = { "CHANGE", "LOVE", "HOPE", "VIEW" };

        String answer = getAnswer(strArr);
        String question = getScrambledWord(answer);

        System.out.println("Question: " + question);
        System.out.println("Answer: " + answer);

    }

    public static String getAnswer(String[] strArr) {

        // Chooses a random index in [0, strArr.length - 1]
        int index = random.nextInt(strArr.length);

        String i = strArr[index];
        return i;

    }

    public static String getScrambledWord(String str) {

        String remaining = str;
        String scrambled = "";

        // Loop over the string, each time choose a random letter
        // and add it to the scrambled word, then remove that letter
        // from the remaining word. Repeat until all letters are gone.
        for (int i = str.length(); i > 0; i--) {

            // Choose the index of a letter in the remaining string
            int index = random.nextInt(remaining.length());

            // Add the letter at the random index to your scambled word
            scrambled += remaining.charAt(index);

            // Remove the chosen character from the remaining sequence
            remaining = remaining.substring(0, index) + remaining.substring(index + 1);

        }

        return scrambled;
    }

}