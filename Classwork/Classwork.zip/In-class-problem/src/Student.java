/**
 * 
 */

/**
 * @author ahack
 *
 */
public class Student implements Comparable<Student> {

	private String name;
	private long ID;

	@Override
	public String toString() {
		return "Student [name=" + name + ", ID=" + ID + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getID() {
		return ID;
	}

	public void setID(long iD) {
		ID = iD;
	}

	public Student(String string, long l) {

	}

	@Override
	public int compareTo(Student o) {
		if (this.ID == o.ID)
			return 0;
		else if (this.ID > o.ID)
			return 1;
		else if (this.ID < o.ID)
			return -1;
		return 0;

	}

}
