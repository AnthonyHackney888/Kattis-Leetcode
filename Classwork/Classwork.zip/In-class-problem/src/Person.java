
public class Person {

	
	
	
	
	
	public static double milesToKilometeres(double m) {
		return m * 1.609;
	}
	public static double kilometersToMiles(double k) {
		return k / 1.609;
	}
	
	
	
	
	/* MISSING
    protected String name;
    protected int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
        
    }

    public abstract String toString();
   */
}