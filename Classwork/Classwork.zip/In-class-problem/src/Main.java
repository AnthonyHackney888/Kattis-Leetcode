import java.awt.Point;
import java.io.IOException;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) throws IOException {
		
		printArray(new Integer[]{1,3,5,7,9});

		
}

	static <E> void printArray(E[] inputArray) {
		for(E element : inputArray) {
			System.out.printf("%s ", element);
		
}
	}
}
	