import java.util.ArrayList;
import javax.swing.JOptionPane;
/*
     * PID: IC1 
     * Author: 	Group 16
	 * Date:   	01/22/18
	 *
	 * Description:  Converting Fahrenheit to Celsius
	 */
public class inclassproblem {
	//static ArrayList<Student> list;
	//static Student student;
	
    public static void main(String[] args) {
    	
    	//Initial
    	
    	
    	
    		int [] Array = { 5, 6, 7, 8,};
    		
    		System.out.print(linearSearch(Array));

    	}
    	public static boolean linearSearch(int Array []) {
    		boolean search = false;
    		
    		for (int i = 0; i<Array.length;i++) {
    			if (Array[i] == 5) {
    				search = true;
    			}
    			
    		}
    		return search;
    		
    	}
    	public static boolean recursiveSearch(int Array [], int num, int targetNum) {
    		boolean search = false;
    		
    		if 
    		
    		
    		return search;
    	}
    	

    	//Get the user input 
    	/*input = JOptionPane.showInputDialog("Enter a distance in miles");
    	
    	miles = Double.parseDouble(input);
    	
    	//Convert it into kilometers
    	kilos = Person.milesToKilometeres(miles);
    	JOptionPane.showMessageDialog(null, String.format("%,.2f miles equals %,.2f kilometers.", miles, kilos));
    	
    	input = JOptionPane.showInputDialog("Enter a distance in kilometeres: ");
    	kilos = Double.parseDouble(input);
    	
    	//Get a distance in kilometers
    	
    	miles = Person.kilometersToMiles(kilos);
    	JOptionPane.showMessageDialog(null, String.format("%,.2f miles kilometers %,.2f miles.", miles, kilos));
    	System.exit(0);
    	
    	
    	/*list = new ArrayList<>(); 
    	list.add(new Student("Jemma", 100));
    	list.add(new Student ("Harry", 100));
    	list.add(new Student ("Zeus", 100));
        
    	double studyTime = 0;
        for(Student student : list) {
        	studyTime+= student.getStudyHours();
        }
        System.out.printf("Average study tim is %.2f hours. ", studyTime/list.size());
        */
    
    }

