

	public interface Course
	{ 
		// MISSING
	    final static String courseName = "CPS 181";
	    
	    String getCourseName();
	}

