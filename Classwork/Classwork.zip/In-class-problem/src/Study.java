import java.util.Scanner;

public interface Study {

	// MISSING
	final static int defaultHours = 12;
	static Scanner keyboard = new Scanner(System.in);

	public static int getStudyHours(String name) { // This is later Java: static method allowed in interface
		System.out.print("Hey, " + name + ", how long did you study? ");
		int hours = Integer.parseInt(keyboard.nextLine());
		return hours;
	}
}
