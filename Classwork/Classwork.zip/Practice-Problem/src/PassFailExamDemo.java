import java.util.Scanner;
public class PassFailExamDemo {

	public static void main (String[] args) {
		int questions;
		int missed;
		double minPassing;
		
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("How many questions are on the exam");
		questions = scnr.nextInt();
		
		System.out.println("How many questions did the student miss? ");
		missed = scnr.nextInt();
		
		System.out.println("What is the minimu passing score? ");
		minPassing = scnr.nextDouble();
		
		PassFailExam exam = new PassFailExam(questions, missed, minPassing);
		
		System.out.println("Each question counts " + exam.getPointsEach() + " points");
		
		System.out.println("");
	}

}
