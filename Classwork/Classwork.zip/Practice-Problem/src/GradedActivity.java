
public class GradedActivity {
	private double score;

	public void setScore(double s) {
		score = s;
	}

	public double getScore() {
		return score;
	}

	public char getGrade() {
		char letterGrade = ' ';
		if (score >= 90)
			letterGrade = 'A';
		else if (score >= 80)
			letterGrade = 'B';
		else if (score >= 80)
			letterGrade = 'C';
		else if (score >= 80)
			letterGrade = 'D';
		else if (score >= 80)
			letterGrade = 'F';
		return letterGrade;
	}

	public GradedActivity() {
		// TODO Auto-generated constructor stub
	}

}
