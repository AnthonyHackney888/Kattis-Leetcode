/**
 * 
 */

/**
 * @author ahack
 *
 */
public class PassFailExam extends PassFailActivity {
	private int numQuestions;
	private int numMissed;
	private double pointsEach;

	/**
	 * 
	 */
	public PassFailExam(int questions, int missed, double minPassing) {
		super(minPassing);

		double numericScore;

		numQuestions = questions;
		numMissed = missed;

		pointsEach = 100.0 / questions;

		numericScore = 100.0 - (numMissed * pointsEach);

		setScore(numericScore);
	}

	public double getPointsEach() {
		return pointsEach;
	}

	public int getNumMissed() {
		return numMissed;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
