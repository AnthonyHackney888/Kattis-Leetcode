import java.io.IOException;
import java.util.LinkedList;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/*
 * author: hackn1a
 * 
 * 
 */
public class Main {

	public static void main(String[] args) {
		try {
			Scanner scnr = new Scanner(new File("Emoji_List.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
