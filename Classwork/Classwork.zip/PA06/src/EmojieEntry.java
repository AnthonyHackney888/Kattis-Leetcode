/**
 * 
 */

/**
 * @author hackn1a
 *
 */
public class EmojieEntry {
	private int num;
	private String ID;
	
	public EmojieEntry() {
		
	}

}
