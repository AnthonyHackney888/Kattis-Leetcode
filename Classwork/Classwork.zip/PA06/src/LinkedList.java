
public class LinkedList {
	private ListNode head;
	private ListNode tail;
	private int length;

	private class ListNode {
		private String data;
		private ListNode next;
		private ListNode previous;

		public ListNode(String data) {
			this.data = data;
		}
	}

	public LinkedList() {
		this.head = null;
		this.tail = null;
		this.length = 0;
	}

	public boolean isEmpty() {
		return length == 0;
	}

	public int length() {
		return length;

	}
}
