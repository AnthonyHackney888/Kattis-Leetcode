
public class problems {

	public static void main(String[] args) {
		int i = 1;
		final int TEN = 10;
		final int NUM_TABLE = 2;
		while (i <= TEN) {
			System.out.println(NUM_TABLE + " x " + i + " = " + (NUM_TABLE * i) );
			i++;
		}
	}

}
