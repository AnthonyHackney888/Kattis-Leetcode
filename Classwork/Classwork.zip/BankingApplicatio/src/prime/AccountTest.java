package prime;

import java.math.BigDecimal;

import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;

import prime.SavingsAccount.NotEnoughFundsException;

class AccountTest {

	@Test
	void testCheckDeposit() {
		Account account = new CheckingAccount(13, BigDecimal.valueOf(0));
		account.deposit(BigDecimal.valueOf(110));
		account.deposit(BigDecimal.valueOf(.50));
	}
	
	
	@Test
	void testCheckWithdraw() {
		Account account = new CheckingAccount(13, BigDecimal.valueOf(0));
		account.deposit(BigDecimal.valueOf(110));
		account.deposit(BigDecimal.valueOf(.50));
		account.withdraw(BigDecimal.valueOf(30));
		account.withdraw(BigDecimal.valueOf(81));
		
		//account.withdraw(BigDecimal.valueOf(-1));
	}

	

	@Test
	void testSaveDeposit() {
		Account accountSav = new SavingsAccount(13, BigDecimal.valueOf(10));
		accountSav.deposit(BigDecimal.valueOf(100));
	}

	@Test
	void testSaveWithdraw() {

		Account accountSav = new SavingsAccount(13, BigDecimal.valueOf(0));
		accountSav.deposit(BigDecimal.valueOf(100));
		accountSav.withdraw(BigDecimal.valueOf(101));
		
		}
	@Rule
    public ExpectedException exception = ExpectedException.none();
	@Test
	void testNotEnoughFundsException() {
		Account defAccount = new SavingsAccount(0, BigDecimal.valueOf(0));
		defAccount.withdraw(BigDecimal.valueOf(1));
		
		exception.expect(NotEnoughFundsException.class);
		exception.expectMessage("Not enough funds");
		
		
	}

}
