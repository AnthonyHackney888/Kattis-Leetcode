package prime;
/**
 * author: Anthony Hackney hackn1a
 * 
 * This  program simulates a banking system
 */
import java.math.BigDecimal;

import bank.Person;
import bank.Teller;

public class Main {

	public static void main(String[] args) {
		Person person1 = new Person("Tony" , "hackney", "1234");//person object
		Person person2 = new Person("Tony2" , "Hackney", "4321");//person object
		Teller teller = new Teller("Name", "Lastname", "1441");//Teller object
		teller.addPerson(person1);//have the teller add a person to the system
		//to test if the axception will work
		//teller.addPerson(person1); 
		
		//initialize a checking and savings accout
		CheckingAccount chAccount = new CheckingAccount(4551223, BigDecimal.valueOf(100));
		SavingsAccount savAccount = new SavingsAccount(231111, BigDecimal.valueOf(50));
		
		teller.openAccount(person1, chAccount);//teller opens the account for person1
	
		
		//testing the ability to withdraw and deposit
		teller.withdraw(person1, chAccount, BigDecimal.valueOf(50));
		teller.withdraw(person1, chAccount, BigDecimal.valueOf(75));
		teller.deposit(person1, chAccount, BigDecimal.valueOf(50));
		teller.closeAccout(person1, chAccount);
		teller.openAccount(person1, savAccount);
		teller.withdraw(person1, savAccount, BigDecimal.valueOf(50));
		teller.withdraw(person1, savAccount, BigDecimal.valueOf(50));

	}

}
