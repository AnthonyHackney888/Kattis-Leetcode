package prime;

public class NotEnoughFundsException2 extends RuntimeException {
	public NotEnoughFundsException2(String string) {

	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 3551283314418179543L;

}
