package prime;

import java.math.BigDecimal;

public class SavingsAccount extends Account {

	/**
	 * 
	 * @param accountNumber persons account number
	 * @param balence       savings account balence
	 */
	public SavingsAccount(int accountNumber, BigDecimal balence) {
		super(accountNumber, balence);

	}

	/**
	 * A withdraw method that subtracts the requested amount and if there is less
	 * than zero will throw an exception
	 */
	@Override
	boolean withdraw(BigDecimal balence) {
		super.setBalence(super.getBalence().subtract(balence));
		if (super.getBalence().compareTo(BigDecimal.ZERO) < 0) {
			return false;

			// throw new NotEnoughFundsException(super.getBalence()+ "Not enough funds");

		}
		System.out.println("The savings balence of: $" + getBalence());
		return true;
	}

	/**
	 * A deposit method to add funds to the account
	 */
	@Override
	boolean deposit(BigDecimal balence) {
		super.setBalence(super.getBalence().add(balence));
		System.out.println("The savings balence is: $" + getBalence());
		return true;

	}

	class NotEnoughFundsException extends RuntimeException {
		public NotEnoughFundsException(String string) {
			super(string);
			
		}

		private static final long serialVersionUID = -3486910112207114966L;
	}
}
