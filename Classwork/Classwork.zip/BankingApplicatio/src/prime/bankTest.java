package prime;

import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;

import bank.Person;
import bank.Teller;

class bankTest {

	@Test
	void testAddPerson() {
		Person p = new Person("a", "b", "c");
		Teller t = new Teller("d", "e", "f");
		System.out.println();
		System.out.println("add person test");
		//testing if the same person can be added twice
		t.addPerson(p);
		//t.addPerson(p);
		
	}
	@Test
	void testRemovePerson() {
		Person p = new Person("a", "b", "c");
		Teller t = new Teller("d", "e", "f");
		System.out.println();
		System.out.println("remove person test");
		t.addPerson(p);
		//checking to see if the person can be removed twice
		t.removePerson(p);
		//t.removePerson(p);
		
	}
	@Test
	void testopenAccount() {
		Person p = new Person("a", "b", "c");
		Teller t = new Teller("d", "e", "f");
		Account a = new SavingsAccount(0, null);
		Account a2 = new CheckingAccount(0, null);
		System.out.println();
		System.out.println("open account test");
		t.addPerson(p);
		t.openAccount(p, a);
		t.openAccount(p, a2);
		

		
		
	}
	@Test
	void testCloseAccount() {
		
		Person p = new Person("a", "b", "c");
		Teller t = new Teller("d", "e", "f");
		Account a = new SavingsAccount(0, null);
		System.out.println();
		System.out.println("close account test");
		//testing if removing a person before opening/closing account
		
		t.addPerson(p);
		//t.removePerson(p);
		t.openAccount(p, a);
		t.closeAccout(p, a);
		
		
	}
	@Test
	void testVerifyAccountExists() {
		Person p = new Person("a", "b", "c");
		Teller t = new Teller("d", "e", "f");
		BankingSystem bank = new BankingSystem();
		Account a = new SavingsAccount(0, null);
		
		System.out.println();
		System.out.println("Verify account test");
		
		t.addPerson(p);
		t.openAccount(p, a);
		//bank.openAccount(p, a);
		
		if(bank.verifyAccountExists(p, a) == true) {
			System.out.println("Account exists");
		}else if(bank.verifyAccountExists(p, a) == false) {
			System.out.println("error");
		}
	}
	@Rule
    public ExpectedException exception = ExpectedException.none();
	
	@Test
	void testPersonDoesNotExistsException() {
		BankingSystem bank = new BankingSystem();
		
		exception.expect(PersonDoesNotExistsException.class);
	
		
		
	}

	@Test
	void testPersonAlreadyExistsException() {
		BankingSystem bank = new BankingSystem();
		
		exception.expect(PersonAlreadyExistsException.class);
	
		
		
	}

	@Test
	void testAccountAlreadyExistsException() {
		BankingSystem bank = new BankingSystem();
		
		exception.expect(AccountAlreadyExistsException.class);
		
		
		
	}
	@Test
	void testAccountDoesNotExistsException() {
		BankingSystem bank = new BankingSystem();
		
		exception.expect(AccountDoesNotExistsException.class);
		
		
		
	}

}
