package prime;

import java.math.BigDecimal;

abstract class Account {

	private int accountNumber; // declare an account number
	private BigDecimal balence;// declare a balance
	/**
	 * 
	 * @param accountNumber - the persons account number 
	 * @param balence - the persons balence
	 */
	public Account(int accountNumber, BigDecimal balence) {
		super();
		this.accountNumber = accountNumber;
		this.balence = balence;
	}

	abstract boolean withdraw(BigDecimal balence);//abstract withdraw method  
	abstract boolean deposit(BigDecimal balence);// abstract deposit method

	public BigDecimal getBalence() {
		return balence;
	}

	public void setBalence(BigDecimal balence) {
		this.balence = balence;
	}

	public int getAccountNumber() {
		return accountNumber;
	}
}
