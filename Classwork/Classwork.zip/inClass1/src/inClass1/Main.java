package edu.cmich.cps181.lecture8.handson1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = null;
		try {
			scanner = openFile();
			while (scanner.hasNext())
				System.out.print(scanner.next());
		} catch (FileNotFoundException ex) {
			System.out.println("Sorry, Dave. I cannot do that.");

		} finally {
			if (scanner != null)
				scanner.close();
			System.out.println("Finally.");
		}

		// Better: try with resources
		try (Scanner scanner2 = openFile()) {
			while (scanner2.hasNext())
				System.out.print(scanner2.next());
		} catch (FileNotFoundException e) {
			System.out.println("Sorry, Dave. I cannot do that.");
		} finally {
			System.out.println("Finally.");
		}
	}

	private static Scanner openFile() throws FileNotFoundException {
		File file = new File("demo.file");
		Scanner scanner = new Scanner(file);
		return scanner;
	}

}
