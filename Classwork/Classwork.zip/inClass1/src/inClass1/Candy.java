package inClass1;

public class Candy {
	// Fields first, in second iteration they are private
	private String name;
	private double count; // enables half a candy bar, otherwise int
	private double kcalPerPiece;

	// The getters/setters
	public String getName() {
		return name;
	}
	/*
	 * @param 
	 */
	public void setName(String candyName) { 
		
		name = candyName;
		
		
	}

	public double getCount() {
		return count;
	}

	public void setCount(double candyCount) {
		count = candyCount;
	}

	public double getKcalPerPiece() {
		return kcalPerPiece;
	}

	public void setKcalPerPiece(double kcal) {
		kcalPerPiece = kcal;
	}
	
	/* 
	 * The method returns the calories in total
	 */
	public double getTotalKcal() {
		return count * kcalPerPiece;
	}
	
	
	// The default constructor - does not take an argument, but initializes the
	// fields appropriately
	Candy() {
		name = "Green Gummybear";
		count = 1.0;
		kcalPerPiece = 8.0;
	}

	// The second constructor, requiring the details as parameters
	Candy(String candyName, double candyCount, double candyKcal) {
		name = candyName;
		count = candyCount;
		kcalPerPiece = candyKcal;
	}
}