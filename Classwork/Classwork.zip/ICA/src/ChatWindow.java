import java.awt.BorderLayout;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.Date;
import java.sql.Timestamp;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * 
 * @author hackn1a
 * 
 *         This program simulates a messenger
 *
 */
public class ChatWindow {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChatWindow window = new ChatWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ChatWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Chat Window");
		frame.setBounds(100, 100, 261, 439);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		// create first text area that wraps text
		// and is not editable
		JTextArea textArea = new JTextArea();
		//make the textArea not editable
		textArea.setEditable(false);
		//make the lines wrap
		textArea.setWrapStyleWord(true);
		textArea.setLineWrap(true);
		textArea.setBounds(10, 30, 223, 333);
		//add the scroll bar to the textArea
		JScrollPane scrollBar = new JScrollPane(textArea);
		scrollBar.setBounds(10, 30, 223, 333);
		panel.add(scrollBar);

		// send button
		JButton submitBtn = new JButton("Send");
		// action listener so that the textField and
		// text Area can interact
		//make the time stamp functions
		Date date = new Date();
		long time = date.getTime();
		Timestamp stamp = new Timestamp(time);
		submitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!textField.getText().isEmpty()) {
					textArea.append(stamp + ": " + textField.getText() + "\n");
					textField.setText("");
				}
			}
		});

		submitBtn.setBounds(156, 373, 77, 23);
		panel.add(submitBtn);

		frame.getRootPane().setDefaultButton(submitBtn);
		// Text field to take in user input and can be submitted

		textField = new JTextField();
		textField.setBounds(10, 374, 145, 20);
		panel.add(textField);
		textField.setColumns(10);
		textField.requestFocusInWindow();

	}
}
