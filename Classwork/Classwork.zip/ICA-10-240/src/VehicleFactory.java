
public interface VehicleFactory {

}
