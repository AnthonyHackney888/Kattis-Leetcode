
public class SportsCar extends Car {

	public SportsCar(String vin, String year) {
		super(vin, year);
	}

	@Override
	public void build() {
		System.out.println("build Sports Car");
	}
}
