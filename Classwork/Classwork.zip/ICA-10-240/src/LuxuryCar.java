
public class LuxuryCar extends Car {

	public LuxuryCar(String vin, String year) {
		super(vin, year);
		// TODO Auto-generated constructor stub
	}
	public void build() {
		System.out.println("Start build sports car");
	}

}
