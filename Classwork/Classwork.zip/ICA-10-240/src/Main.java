import java.util.ArrayList;
import java.util.Scanner;
/**
 * 
 * @author Anthony Hackney, hackn1a
 * This program uses the factory method
 *
 */

public class Main {
	private static ArrayList<Car> cars = new ArrayList<>();

	public static void main(String[] args) {
		Main.loop();
	}
	
	public static void loop() {
		System.out.println("Enter car type");
		Scanner scnr = new Scanner(System.in);
		String userInput = scnr.next();
		
		while(!userInput.equals("exit")) {
			if(!userInput.equals("exit")) {
				Car car = CarFactory.getCar(userInput);
				cars.add(car);
				System.out.println("Car has been added");
				break;
			}if(userInput.equals("exit")) {
				System.out.println("exiting");
				System.exit(0);
			}
		}
		
	}


}
