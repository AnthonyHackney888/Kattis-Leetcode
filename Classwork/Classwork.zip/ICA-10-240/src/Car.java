
public class Car {
	private String vin;
	private String year;
	 public Car(String vin, String year) {
		 this.vin = vin;
		 this.year = year;
	 }
	 public double accelerate(double speed) {
		 double calc= 9.9;
		 speed = calc;
		 return speed;
	 }
	 public void build() {
		 
	 }
	 public void stop() {
		 
	 }
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}

}
