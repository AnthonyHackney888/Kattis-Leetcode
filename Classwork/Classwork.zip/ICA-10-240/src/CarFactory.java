
public class CarFactory {
	public static Car getCar(String type) {
	Car car;
	switch(type) {
	case "Luxury Car":
		car = new LuxuryCar(type, type);
		break;
	case"Sports Car":
		car = new SportsCar(type, type);
		break;
	default:
		car = null;
		break;
	}
	return car;
	}
}
