package lab2;
/*
 * author: Anthony Hackney, hackn1a
 * 
 * find the min distance and the best route of a Traveling Sales Person.
 */
import java.util.Random;


public class Lab2 {

private static int[][] adjMatrix;
private static int n;
private int[] bestSolution;
private int bestDistance;

public Lab2(int nNums) {
 n = nNums;
 fillMatrix();
 bestDistance = 11 * n;
 bestSolution = new int[n];
}

private static void fillMatrix() {
 
 int n = 3;
//  Random rand = new Random();
//  int randomInt = rand.nextInt(10);
 adjMatrix = new int[n][n];
 for(int i = 0; i < adjMatrix.length ; i++) {
  for(int j = 0; j <adjMatrix[i].length; j++ ) {
   
    adjMatrix[i][j] = (int)(Math.random() * 10);  
    
  }
 }
}

private void printSolution() {
 System.out.println("Min distance is " + bestDistance);
 System.out.println("Best route is ");
 for (int i = 0; i < n; i++) {
  System.out.print(bestSolution[i] + " ");
 }
}

private void genPermutation() {
 int[] permArray = new int[n];
 for (int i = 0; i < n; i++) {
  permArray[i] = i;
 }

 heapPermutation(permArray, permArray.length, permArray.length);
}

void findBestSolution(int a[], int n) {
	//the min distance
	int distance = 0;
	for(int i = 0; i < adjMatrix.length; i++) {
		for(int j = 0; j < adjMatrix[i].length; j++) {
			//finding the distance by adding things in 
			//adjMatrix
			distance += adjMatrix[i][0];
				//if the distance is less than the
				//best distance then set bestDistance to 
				//distance
				if(bestDistance > distance){
					bestDistance = distance;
				
			}
		}
	}
	//Copying the a[] array to the bestSolution array
	for(int i = 0; i < a.length; i++) {
			bestSolution = new int[a.length];
			System.arraycopy(a, 0, bestSolution, 0, bestSolution.length);
		
	}
	
 // find Best Solution
 // find the distance using array a and adjMatrix (indices)
 // compare distance with bestdistance so far
 // if smaller than the set then bestdistnce is changed
 
}

// Generating permutation using Heap Algorithm
void heapPermutation(int a[], int size, int n) {
 // if size becomes 1 then prints the obtained
 // permutation
 if (size == 1)
  findBestSolution(a, n);

 for (int i = 0; i < size; i++) {
  heapPermutation(a, size - 1, n);

  // if size is odd, swap first and last
  // element
  if (size % 2 == 1) {

   int temp = a[0];
   a[0] = a[size - 1];
   a[size - 1] = temp;
  }

  // If size is even, swap ith and last
  // element

  else {

   int temp = a[i];
   a[i] = a[size - 1];
   a[size - 1] = temp;

  }
 }
}

public static void main(String[] args) {

 // generate adjacency matrix with random integer distances for numbers 1-n
 // find shortest route through the matrix


 //for loop set to 12 as thats as many it can get before
//the program stalls.
 for(int i = 0; i < 1; i++) {
 long startTime = System.nanoTime();
 System.out.println(i+"----------");
 Lab2 tsp = new Lab2(i);
 tsp.genPermutation();
 tsp.printSolution();
 long endTime = System.nanoTime();
 System.out.println((endTime-startTime)/100000000.0); //report as seconds
 }
}

}