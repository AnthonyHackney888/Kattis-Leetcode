
/*
 * author: Anthony Hackney, hackn1a
 * date: 10/17/19
 * 
 * mimics the fake coin method 
 */
import java.util.Arrays;

public class lab3 {

	public static void main(String[] args) {

		int fakeCoin = 3;
		int[] array = { 1, 2, fakeCoin, 4, 5, 6, 7, 8, 9, 10 };
		int[] array2 = { 1, 2, 4, 4, 5, 6, fakeCoin, 8, 9, 10 };

		divideCoin(array);
		divideCoin(array2);

	}

	/*
	 * This method splits the array into two and checks which side is lighter
	 */
	public static void divideCoin(int[] a) {
		int leftWeight[] = new int[(a.length + 1) / 2];
		int rightWeight[] = new int[a.length - leftWeight.length];
		int fakeCoin = 3;

		System.arraycopy(a, 0, leftWeight, 0, leftWeight.length);
		System.arraycopy(a, leftWeight.length, rightWeight, 0, rightWeight.length);

		System.out.println(Arrays.toString(leftWeight));
		System.out.println(Arrays.toString(rightWeight));

		if (whichIsLighter(leftWeight, rightWeight, fakeCoin) == 1) {
			System.out.println("The coin is on the left pile");
		} else if (whichIsLighter(leftWeight, rightWeight, fakeCoin) == 2) {
			System.out.println("The coin is on the right pile");
		} else if (whichIsLighter(leftWeight, rightWeight, fakeCoin) == 3) {
			System.out.println("The coin is on the leftover pile");
		}

	}

	/**
	 * Checks which array is lighter
	 * 
	 * @param a        - the first split array
	 * @param b        - the second part of the split array
	 * @param fakeCoin - the decided fake coin
	 * @return - returns the condition if the fake coin is on the left or right
	 */
	public static int whichIsLighter(int[] a, int[] b, int fakeCoin) {
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < b.length; j++) {
				if (a[i] == fakeCoin) {
					return 1;
				}
				if (b[j] == fakeCoin) {
					return 2;
				}
			}
		}
		return 3;
	}
}