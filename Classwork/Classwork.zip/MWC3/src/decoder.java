import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;

public class decoder {
	public ArrayList<String> array = new ArrayList<String>();

	@Override
	public String toString() {
		return "decoder [array=" + array + "]";
	}

	public decoder(ArrayList<String> array, int numbre, String symbol, String letter) throws FileNotFoundException {
		super();
		this.array = array;
		this.numbre = numbre;
		this.symbol = symbol;
		this.letter = letter;
		
		File f = new File("secret-message.txt");
		Scanner scnr = new Scanner(f);
		while (scnr.hasNext()) {
			array.add(f);
		}

	}

	public ArrayList<String> getArray() {
		return array;
	}

	public void setArray(ArrayList<String> array) {
		this.array = array;
	}

	public decoder() {
		// TODO Auto-generated constructor stub
	}

	private int numbre;
	private String symbol;
	private String letter;

	public int getNumbre() {
		return numbre;
	}

	public void setNumbre(int numbre) {
		this.numbre = numbre;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getLetter() {
		return letter;
	}

	public void setLetter(String letter) {
		this.letter = letter;
	}

	public void readFile(ArrayList<String> array) {
		
			}
	

	public void numberThing(ArrayList<String> array) {

	}

	public void symbols(ArrayList<String> array) {
		int value = 0;
		for (int i = 0; i < array.size(); i++) {
			if (array.get(i) == "!") {
				value = 1;
				value = (11 * value / 5 + 97);
			}
			if (array.get(i) == "@") {
				value = 2;
				value = (11 * value / 5 + 97);
			}
			if (array.get(i) == "#") {
				value = 3;
				value = (11 * value / 5 + 97);

				if (array.get(i) == ")") {
					value = 0;
					value = (11 * value / 5 + 97);
				}
				System.out.println(value);
			}
		}
	}
}