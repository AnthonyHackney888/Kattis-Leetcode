package food;

public abstract class FoodItem implements GetFoodDetails {
	
	private String name;//
	private int caloriesPerServing; //
	private double weightPerServing; //

	/**
	 * @param name
	 * @param caloriesPerServing
	 * @param weightPerServing
	 */
	public FoodItem(String name, int caloriesPerServing, double weightPerServing) {
		this.name = name;
		this.caloriesPerServing = caloriesPerServing;
		this.setWeightPerServing(weightPerServing);
	}

	/**
	 * @return
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * @return
	 */
	public int getCaloriesPerServing() {
		return caloriesPerServing;
	}

	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return this.getName() + " (" + getCalories() + " kcal /" + getWeight() + "g)";
	}

	/**
	 * @return
	 */
	public double getWeightPerServing() {
		return weightPerServing;
	}

	/**
	 * @param weightPerServing
	 */
	public void setWeightPerServing(double weightPerServing) {
		this.weightPerServing = weightPerServing;
	}
}