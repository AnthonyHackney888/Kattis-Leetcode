package food;

/**
 * @author ahack
 *
 */
public class Froyo extends FoodItem implements  GetFoodDetails {
	/**
	 * @param name
	 * @param caloriesPerServing
	 * @param weightPerServing
	 */
	public Froyo(String name, int caloriesPerServing, double weightPerServing) {
		super(name, caloriesPerServing, weightPerServing);
	}

	/* 
	 * Returns the getCaloriesPerServing from the implemented GetFoodDetails
	 */
	@Override
	public int getCalories() {
		return this.getCaloriesPerServing();
 
	}

	/* 
	 * Returns the getWeightPerServing from the implemented GetFoodDetails
	 */
	@Override
	public double getWeight() {
		return this.getWeightPerServing();
		
	}
	/*
	 * returns the toString from the superclass 
	 */
	@Override
	public String toString() {
		return super.toString();
	}
}