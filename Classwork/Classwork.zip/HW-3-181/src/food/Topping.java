package food;

/**
 * @author ahack
 *
 */
public class Topping extends FoodItem implements GetFoodDetails {

	/* (non-Javadoc)
	 * @see food.FoodItem#toString()
	 */
	@Override
	public String toString() {
		return super.toString();
	}

	/**
	 * @param name
	 * @param caloriesPerServing
	 * @param weightPerServing
	 */
	public Topping(String name, int caloriesPerServing, double weightPerServing) {
		super(name, caloriesPerServing, weightPerServing);
	}

	/* (non-Javadoc)
	 * @see food.GetFoodDetails#getCalories()
	 */
	@Override
	public int getCalories() {
		return this.getCaloriesPerServing();
	}

	/* (non-Javadoc)
	 * @see food.GetFoodDetails#getWeight()
	 */
	@Override
	public double getWeight() {
		return this.getWeightPerServing();
	}
}
