package food ;

 public interface GetFoodDetails {
 int getCalories () ; // full kcals
 double getWeight () ; // weight in grams
 }
