package food;

public interface ToppingList {
	public static final Topping MANDMS = new Topping("M&Ms", 240, 48);
	public static final Topping REESES = new Topping(" Reeses Mini Cups ", 200, 39);
	public static final Topping ALMONDS = new Topping("Raw Almonds ", 163, 28);
	public static final Topping PEANUTS_RAW = new Topping("Raw Peanuts ", 161, 28);
	public static final Topping PEANUTS_ROASTED = new Topping(" Roasted Peanuts ", 248, 42);
	public static final Topping Chocolate = new Topping("Chocolate", 114, 72);
	public static final Topping vanilla = new Topping ("Vanilla", 115, 72);
	public static final Topping Taro = new Topping("Taro", 95, 72);
}