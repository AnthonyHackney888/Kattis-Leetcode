 package shoppe ;

 public interface Checkout {
 double PRICE_PER_OZ = 1.00;
 double TAX_RATE = 6; // 6% tax rate
 int MAX_ITEMS = 5; // 5 items that fit in a cup

 int getWeight () ;//
 int totalCalories () ;//
 double weightToDollars ( double weightInGrams ) ; 
 double taxAmount ( double preTaxDollars ) ; 
 }