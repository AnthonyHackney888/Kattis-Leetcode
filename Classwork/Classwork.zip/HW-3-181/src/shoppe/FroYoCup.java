package shoppe;

import java.util.ArrayList;

import food.FoodItem;

/**
 * @author ahack
 *
 */
public class FroYoCup implements Checkout {
	
	ArrayList<FoodItem> contents;//array list to store the items

	public FroYoCup() {
		this.contents = new ArrayList<>();
	}

	/**
	 * @param item
	 * @return a true or false based on how many items are added to the content arraylist
	 */
	public boolean addItem(FoodItem item) {
		if (contents.size() < Checkout.MAX_ITEMS) {
			contents.add(item);
			return true;
		}

		return false;
	}

	/*
	 *  returns the calories from the contents array
	 */
	@Override
	public int totalCalories() {
		int totCal = 0;
		for (FoodItem r : contents) {
			totCal += r.getCaloriesPerServing();
		}
		return totCal;

	}

	/*
	 * return the get weight from the 
	 *
	 */
	@Override
	public double weightToDollars(double weightInGrams) {
		

		return this.getWeight()/28.3;

	}

	/*
	 * returns the amount for Tax 
	 * 
	 */
	@Override
	public double taxAmount(double preTaxDollars) {		

		return (preTaxDollars += TAX_RATE)/100;
	}

	/**
	 * @param preTaxDollars
	 * adds the before and after tax amounst giving the total
	 * @return preTaxdollars
	 */
	public double fullTaxAmount(double preTaxDollars) {

		preTaxDollars = taxAmount(preTaxDollars) + weightToDollars(preTaxDollars);

		return preTaxDollars;

	}

	/*
	 * A toString to return the contents weight and total calories 
	 * 
	 */
	@Override
	public String toString() {
		return contents + "\n" + "weight: " + getWeight() +" g" + "\n" + "totalCalories: " + totalCalories()+ " kcal";
	}

	/*
	 *returns the weight from the contents array
	 *
	 */
	@Override
	public int getWeight() {
		int topWeight = 0;
		for (FoodItem g : contents) {
			topWeight += g.getWeightPerServing();
		}
		return topWeight;
	}
}