/*
 * author hackn1a
 * 
 * This program creates a recipt for items from a FroYo Shop
 * 
 */
package shoppe;
import food.ToppingList;

public class Main {

	public static void main(String[] args) {

		// create three cups to display and 
		// get their weight to dollars
		// tax and the combined total
		
		FroYoCup cup1 = new FroYoCup();
		FroYoCup cup2 = new FroYoCup();
		FroYoCup cup3 = new FroYoCup();
		//cup 1 topping list adding from the 
		//ToppingList interface
		cup1.addItem(ToppingList.Taro);
		cup1.addItem(ToppingList.Taro);
		cup1.addItem(ToppingList.MANDMS);
		cup1.addItem(ToppingList.Taro);
		cup1.addItem(ToppingList.MANDMS);
		
		//prints the toString from the FroYoCup class
		//Displays the price, tax, and combined total for cup1
		System.out.println(cup1.toString());
		System.out.println("Price before tax: $" + cup1.weightToDollars(5));
		System.out.println("Tax ammount: $" + cup1.taxAmount(5));
		System.out.println("After tax: $" + cup1.fullTaxAmount(5));
				
		//cup 2 topping list adding from the 
		//ToppingList interface
		System.out.println(" ");
		cup2.addItem(ToppingList.vanilla);
		cup2.addItem(ToppingList.MANDMS);
		cup2.addItem(ToppingList.PEANUTS_RAW);
		cup2.addItem(ToppingList.MANDMS);
		cup2.addItem(ToppingList.PEANUTS_RAW);
		
		//prints the toString from the FroYoCup class
		//Displays the price, tax, and combined total for cup2
		System.out.println(cup2.toString());
		System.out.println("Price before tax: $" + cup2.weightToDollars(5));
		System.out.println("Tax ammount: $" + cup2.taxAmount(5));
		System.out.println("After tax: $" + cup2.fullTaxAmount(5));
		
		//cup 3 topping list adding from the 
		//ToppingList interface
		System.out.println(" ");
		cup3.addItem(ToppingList.Taro);
		cup3.addItem(ToppingList.Chocolate);
		cup3.addItem(ToppingList.PEANUTS_RAW);
		cup3.addItem(ToppingList.REESES);
		cup3.addItem(ToppingList.MANDMS);
		
		//prints the toString from the FroYoCup class
		//Displays the price, tax, and combined total for cup3
		System.out.println(cup3.toString());
		System.out.println("Price before tax: $" + cup3.weightToDollars(5));
		System.out.println("Tax ammount: $" + cup3.taxAmount(5));
		System.out.println("After tax: $" + cup3.fullTaxAmount(5));


	}

}
