/**
 * 
 * @author hackn1a
 * The book subclass that extends from the media
 * 
 */
public class Book extends Media {

	private int pages;// the number of pages in the book

	/**
	 * Constructor for the Book class that takes paramaters from the Media
	 * superclass
	 * 
	 * @param availability - availability of the Book
	 * @param id - id of the Book media
	 */
	public Book(boolean availability, int id, int pages) {
		super(availability, id);
		this.pages = pages;

	}

	public int getPages() {
		return pages;
	}

	public void setPages(int pages) {
		this.pages = pages;
	}

}
