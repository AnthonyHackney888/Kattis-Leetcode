import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * @author hackn1a
 * The library class can add a borrower into the system,
 * check if they borrower is in the system read from a file the media items
 * return media items, check if they are available, and check it out
 *
 */
public class Library {
	private Media media;//
	private ArrayList<Media> mediaItems; // ArrayList for the media items
	private ArrayList<Borrower> borrowerID; // ArrayList for the borrowers in the system

	/**
	 * A constructor that holds the scanner for the file and parses through the file
	 * and adds the items into the arraylist
	 * 
	 * @throws FileNotFoundException
	 */
	public Library() throws FileNotFoundException {
		mediaItems = new ArrayList<>();

		File file = new File("Media.txt");
		Scanner scnr = new Scanner(file);

		while (scnr.hasNext()) {
			String[] line = scnr.nextLine().split(",");
			if (line[2].equals("DvD")) {
				Media media = new DvD(Boolean.parseBoolean(line[1]), Integer.parseInt(line[0]), 0.0);
				mediaItems.add(media);
			} else if (line[2].equals("Book")) {
				mediaItems.add(media);
			}
		}
	}

	public ArrayList<Media> getMediaItems() {
		return mediaItems;
	}

	public ArrayList<Borrower> getBorrowerID() {
		return borrowerID;
	}

	/**
	 * This method adds a borrower into the system
	 * 
	 * @param borrowerID - arrray to hold the borrower
	 * @throws FileNotFoundException 
	 */
	public void addBorrower(ArrayList<Borrower> borrowerID) throws FileNotFoundException {
		for (int i = 0; i < borrowerID.size(); i++) {
			
		}
		if (borrowerID.equals(borrowerID)) {
			System.out.println("user already exists");
		}

	}

	/**
	 * This method returns the media and sets the availability back to true
	 * 
	 * @param media - reference to the media class and checks the availability
	 */
	public void returnMedia(Media media) {
		for (int i = 0; i < mediaItems.size(); i++) {
			if (mediaItems.contains(media) && media.isAvailability()) {
				media.setAvailability(true);
			} else {
				System.out.println("The item has already been returned");
			}
		}

	}

	/**
	 * This method checks out the media
	 * 
	 */
	public void checkOut() {
		for (int i = 0; i < mediaItems.size(); i++) {
			if (!mediaItems.isEmpty()) {
			} else {
				System.out.println("The item is already checked out.");
			}
		}

	}

	/**
	 * This method checks if the media item is available
	 * 
	 * @param mediaItems - array holds the mediaItems
	 */
	public void checkAvail(ArrayList<Media> mediaItems) {
		for (int i = 0; i < mediaItems.size(); i++) {
			if (mediaItems.contains(media)) {
				media.isAvailability();
			} else {
				System.out.println("The item is unavailable");
			}
		}
	}

}
