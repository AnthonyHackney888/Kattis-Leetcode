import java.io.FileNotFoundException;
import java.math.BigDecimal;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		// creating 3 different borrowers to test and initializing library and librarian
		// objects should have come up with better names than l, and libraian
		Borrower borrower1 = new Borrower(5, "Tony", BigDecimal.valueOf(40.00));
		Borrower borrower2 = new Borrower(4, "Anthony", BigDecimal.valueOf(20.00));
		Borrower borrower3 = new Borrower(10, "Anthony 2", BigDecimal.valueOf(0.00));
		Library l = new Library();
		Librarian librarian = new Librarian();
		//print out list to test
		System.out.println(l.getMediaItems());
		
		System.out.println("--------------------------------------------------");
		//print out to test
		System.out.println("Name of borrower: " + borrower1.getName());
		System.out.println("Amount fined for overdue books: ");
		librarian.checkFine(borrower1);
		borrower1.payFines();
		System.out.println(borrower1.getName() + " has decided to pay his fines, his new balence is: ");
		librarian.checkFine(borrower1);
		
		
		
		System.out.println("--------------------------------------------------");
		
		System.out.println("Name of borrower: " + borrower2.getName());
		System.out.println("Amount fined for overdue books: ");
		librarian.checkFine(borrower2);
		borrower1.payFines();
		System.out.println(borrower2.getName() + " has decided to pay his fines, his new balence is: ");
		librarian.checkFine(borrower2);
		
		System.out.println("--------------------------------------------------");
		
		System.out.println("Name of borrower: " + borrower3.getName());
		System.out.println("Amount fined for overdue books: ");
		librarian.checkFine(borrower3);
		borrower1.payFines();
		System.out.println(borrower3.getName() + " has decided to pay his fines, his new balence is: ");
		librarian.checkFine(borrower3);
		
	}

}
