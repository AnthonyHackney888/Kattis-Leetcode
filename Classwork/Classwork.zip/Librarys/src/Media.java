/**
 * 
 * @author hackn1a
 *The media superclass that holds information of either a book 
 *or DvD
 */

public class Media {

	private boolean availability;// availability of the media
	private int id;// id of the media

	/**
	 * Constructor for the Media class
	 * 
	 * @param availability - availability of the media
	 * @param id - id for the media
	 */
	public Media(boolean availability, int id) {
		this.availability = availability;
		this.id = id;
	}

	public boolean isAvailability() {
		return availability;
	}

	public void setAvailability(boolean availability) {
		this.availability = availability;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
