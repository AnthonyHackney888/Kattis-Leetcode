/**
 * 
 * @author hackn1a
 * The DvD subclass that extends from the media class
 *
 */
public class DvD extends Media {
	private double length; // length of the DvD

	/**
	 * Constructor for the DvD class that takes pramaters from the Media superclass
	 * 
	 * @param availability - availability of the DvD
	 * @param id - id of the DvD
	 */
	public DvD(boolean availability, int id, double length) {
		super(availability, id);
		this.length = length;

	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

}
