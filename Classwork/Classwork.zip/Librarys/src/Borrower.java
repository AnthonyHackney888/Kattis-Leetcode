import java.util.ArrayList;
import java.io.FileNotFoundException;
import java.math.BigDecimal;

/**
 * 
 * @author hackn1a 
 * This class is for a borrower that can hold a media item and
 * either check it out return it or pay the fines. It interacts with the
 * librarian
 */
public class Borrower extends Librarian {
	private int id;// id of the borrower
	private String name;// name of the borrower
	private BigDecimal fineAmount;// amount that the borrower owes
	private ArrayList<Media> mediaItems; // media List to contain the media in the library

	public ArrayList<Media> getMediaList() {
		return mediaItems;
	}

	public void setMediaList(ArrayList<Media> mediaItems) {
		this.mediaItems = mediaItems;
	}

	/**
	 * @param id - id for the borrower
	 * @param name - name of the borrower
	 * @param fineAmount - amount owed 
	 * @throws FileNotFoundException
	 */
	public Borrower(int id, String name, BigDecimal fineAmount) throws FileNotFoundException {
		this.id = id;
		this.name = name;
		this.fineAmount = fineAmount;
	}

	public BigDecimal getFineAmount() {
		return fineAmount;
	}

	public void setFineAmount(BigDecimal fineAmount) {
		this.fineAmount = fineAmount;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * This method gives the bowrrower the option to pay the fine
	 */
	public void payFines() {
			setFineAmount(fineAmount.subtract(fineAmount));
	}

	/**
	 * interacts with the Librarian class
	 * and checks out a book
	 * @throws FileNotFoundException 
	 */
	public void checkOut() throws FileNotFoundException {
		Librarian l = new Librarian();
		for(int i = 0; i<mediaItems.size();i++) {
			l.checkAvail(mediaItems);
		}
	}

	/**
	 * Interacts with the Librarian class
	 * and returns a media item to the library
	 * 
	 */
	public void returnMedia(){
		Librarian l = new Librarian();
		for(int i = 0; i<mediaItems.size();i++) {
			try {
				l.returnMedia(mediaItems);
			} catch (FileNotFoundException e) {
				
				e.printStackTrace();
			}
		}
	}

	
}
