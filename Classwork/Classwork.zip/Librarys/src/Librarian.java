import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 * 
 * @author hackn1a
 *	This class is the go betwen for the library and the borrower 
 *and can check if the borrower has fines
 */
public class Librarian {

	public Librarian() {
	}
	/**
	 * This method checks if the media Items are still available
	 * @param mediaItems array for mediaitems
	 * @throws FileNotFoundException
	 */
	public void checkAvail(ArrayList<Media> mediaItems) throws FileNotFoundException {
		Library l = new Library();
		l.checkAvail(mediaItems);
	}
	/**
	 * This method is the in between of the Borrower and Library class
	 * to check out media
	 * @throws FileNotFoundException
	 */
	public void checkOut() throws FileNotFoundException {
		Library l = new Library();
		l.checkOut();
	}

	/**
	 * This method is the in between of the Borrower and Library class
	 * to return media
	 * @param mediaItems - array for the media items
	 * @throws FileNotFoundException
	 */
	public void returnMedia(ArrayList<Media> mediaItems) throws FileNotFoundException {
		Library l = new Library();
		for(int i = 0; i <mediaItems.size(); i++) {
			l.returnMedia(mediaItems.remove(i));
		}

	}

	/*
	 * This method checks the fine of the borrower
	 * @param borrower - checks the fine from the borrower
	 */
	public void checkFine(Borrower borrower) {
		System.out.println(borrower.getFineAmount());
		
	}

	/**
	 * This method adds a borrower into the Library
	 * @param borrower - adds the borrower into the array
	 * @throws FileNotFoundException 
	 */
	public void addBorrower(Borrower borrower) throws FileNotFoundException {
		Library l = new Library();
		l.getBorrowerID();	
	}

}
