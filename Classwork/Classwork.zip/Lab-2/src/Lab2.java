
import java.util.Random;
import java.util.Scanner;

/**
 * @author hackn1a
 *
 */
public class Lab2 {

	// Our keyboard scanner
	static Scanner in = new Scanner(System.in);

	public static void main(String[] args) {
		boolean nextGame = true;
		while (nextGame) {
			// Play one game
			oneGame();

			// Check if we want to continue
			System.out.print("Shall we play one more (y/n)? ");
			String next = in.nextLine();
			if ((next.charAt(0) == 'y') || (next.charAt(0) == 'Y'))
				nextGame = true;
			else
				nextGame = false;
		}
		System.out.println("Goodbye!");
	}

	public static void oneGame() {
		char[][] playField = { { ' ', ' ', ' ' }, { ' ', ' ', ' ' }, { ' ', ' ', ' ' } };

		// Game loop
		while (true) {
			printBoard(playField);
			getUserInput(playField);

			if (findWin('X', playField)) {
				System.out.println("Congratulations, you won!");
				break;
			}
			if (findTie(playField)) {
				System.out.println("It's a draw!");
				break;
			}

			getComputerInput(playField);
			if (findWin('O', playField)) {
				System.out.println("Better luck next time!");
				break;
			}
			if (findTie(playField)) {
				System.out.println("It's a draw!");
				break;
			}

			// Next round, show where we are
			printBoard(playField);
		}
		printBoard(playField);
	}

	public static void getUserInput(char[][] playField) {
		boolean valid = false;

		while (!valid) {
			System.out.print("Please enter your move (row and col, no space): ");
			String move = in.nextLine();
			if (move.length() == 2) {
				int row = (int) move.charAt(0) - 97;
				int col = (int) move.charAt(1) - 49;

				if (((row == 0) || (row == 1) || (row == 2)) && ((col == 0) || (col == 1) || (col == 2))) {
					if (playField[row][col] == 0 || playField[row][col] == ' ') {
						playField[row][col] = 'X';
						valid = true;
					} else {
						System.out.println("This field is already taken, choose another!");
					}
				} else {
					System.out.println("This field is invalid!");
				}
			} else {
				System.out.println("Please only enter the right code (a1,...) for the play!");
			}
		}
	}

	public static void getComputerInput(char[][] playField) {
		// Computer move
		boolean valid = false;
		Random rand = new Random();
		while (!valid) {
			int row = rand.nextInt(2);
			int col = rand.nextInt(2);

			if (((row == 0) || (row == 1) || (row == 2)) && ((col == 0) || (col == 1) || (col == 2))) {
				if (playField[row][col] == 0 || playField[row][col] == ' ') {
					playField[row][col] = 'O';
					valid = true;
				} else {
					valid = false;

				}
			}
		}

	}

	public static boolean findTie(char[][] playField) {
		// Determine TIE condition
		for (int row = 0; row < playField.length; ++row) {
	        for (int col = 0; col < playField[row].length; ++col) {
	        	if(playField[row][col] ==' ') {
	        		return false;
	        	}
	        }
	        }
		 
				return true;
	}

	public static boolean findWin(char playerChar, char[][] playField) {
		int winSum = playField.length * (int) playerChar;
		int sum = 0;
		boolean gameOver = false;
		// down
		for (int i = 0; i < playField.length; i++) {
			sum = 0;
			for (int j = 0; j < playField[i].length; j++) {
				sum += (int) playField[j][i];
			}
			if (sum == winSum)
				gameOver = true;
		
		}
		// Across
		for (int i = 0; i < playField.length; i++) {
			sum = 0;
			for (int j = 0; j < playField[i].length; j++) {
				sum += (int) playField[i][j];
			}
			if (sum == winSum)
				gameOver = true;
		}
		// Diagonal (top right, low left)
		/*sum = 0;
		for (int i = 0, j = 0; i < playField.length && j < playField[0].length; i++, j++) {
			sum += (int) playField[i][j];
		}
		if (sum == winSum)
			gameOver = true;
*/
		// Diagonal (top left, low right)
		sum = 0;
		for (int i = 0, j = 0; i < playField.length && j < playField[0].length; i++, j++) {
			sum += (int) playField[i][j];
		}
		if (sum == winSum)
			gameOver = true;

		return gameOver;
	}

	public static void printBoard(char[][] playField) {
		// Print the board
		System.out.println("     1     2     3");
		System.out.println("  +-----+-----+-----+");
		System.out.println("a |  " + playField[0][0] + "  |  " + playField[0][1] + "  |  " + playField[0][2] + "  |");
		System.out.println("  |-----+-----+-----|");
		System.out.println("b |  " + playField[1][0] + "  |  " + playField[1][1] + "  |  " + playField[1][2] + "  |");
		System.out.println("  |-----+-----+-----|");
		System.out.println("c |  " + playField[2][0] + "  |  " + playField[2][1] + "  |  " + playField[2][2] + "  |");
		System.out.println("  +-----+-----+-----+");

	}

}
