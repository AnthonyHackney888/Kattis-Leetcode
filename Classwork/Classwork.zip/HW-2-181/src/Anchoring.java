
public interface Anchoring {
		boolean anchorShipInHarbor(Ship ship);

		// Sails a ship into harbor.
		void sailShipFromHarbor(int anchorSpot);

		// Ship sails away from anchor spot.
		int shipsInHarbor();
		// How many ships are there?
		
	}
	

