
public class CargoShip extends Ship {
	private int shipTonnage;

	public CargoShip() {

	}

	/**
	 * @param shipTonnage - records the ship tonnage of cargo ships
	 * @param name - the name of the ship
	 * @param year - the year the ship was created
	 */
	public CargoShip(int shipTonnage, String name, int year) {
		super(year, name);
		this.shipTonnage = shipTonnage;
	}

	/* 
	 * creates a toString that takes in the constructor in the main class and 
	 * outputs the type of ship and ship tonnage
	 */
	@Override
	public String toString() {

		return "Cargo Ship " + super.toString() + ", tonneage: " + shipTonnage;
	}

	/**
	 * @return shipTonnage
	 */
	public int getShipTonnage() {
		return shipTonnage;
	}

	/**
	 * @param takes the data from the private field and sets it to 
	 * the new variable
	 */
	public void setShipTonnage(int shipTonnage) {
		this.shipTonnage = shipTonnage;
	}

}
