
public class CruiseShip extends Ship {

	private int maxPassengers; //the max passengers of a cruiseship thats unique to the Cruiseship class

	/**
	 * @param year -taken from the super class ship
	 * @param name - taken from the super class ship
	 * @param Passengers - the max number of passengers
	 */
	public CruiseShip(int year, String name, int Passengers) {
		super(year, name);
		maxPassengers = Passengers; //now passengers is able to be changed
		

	}

	/* 
	 * Overrides the super class and classifies what kind of ship it is
	 * and the amount of passengers it can hold 
	 */
	@Override
	public String toString() {
		return "Cruise Ship " + super.toString() + ", passengers: " + getMaxPassengers();
	}

	/**
	 * @return max passengers
	 */
	public int getMaxPassengers() {
		return maxPassengers;
	}

	/**
	 * @param maxPassengers sets maxPassengers to the new created variable
	 */
	public void setMaxPassengers(int maxPassengers) {
		this.maxPassengers = maxPassengers;
	}

}
