
public interface LoadingPier {
		
		public boolean pierIsBusy(); // Whether or not a ship is using the pier.

		public boolean startPier(int anchorSpot); // Put a ship from anchor at the pier.

		public boolean donePier(); // Ship is done at the pier, put into anchor spot.
	}	


