/*
 * author hackn1a
 * 
 * This code directs ships into the pier or harbor 
 * by taking information from other classes
 */
public class Main {

	public static void main(String[] args) {
		Harbor harbor = new Harbor();// create object that calls the harbor class

		//add the ships by calling the ship, CruiseShip, and the CargoShip classes
		//
		Ship ship = new Ship(-1, "Unknown");
		CruiseShip ship1 = new CruiseShip(1589, "Titanic", 10);
		CargoShip ship2 = new CargoShip(1000, "Santa Maria", 55355);
		CruiseShip ship3 = new CruiseShip(1981, "Carnival Triumph", 1100);
		Ship ship4 = new Ship(-1, "U-boat");
		
		//run through the harbor program and testing the classes 
		//first by adding the ships one by one
		harbor.anchorShipInHarbor(ship);
		System.out.println("Created new ship: " + ship);
		System.out.println(harbor.toString());

		
		harbor.anchorShipInHarbor(ship1);
		System.out.println("Created new ship: " + ship1);
		System.out.println(harbor.toString());

		
		harbor.anchorShipInHarbor(ship2);
		System.out.println("Created new ship: " + ship2);
		System.out.println(harbor.toString());

		
		harbor.anchorShipInHarbor(ship3);
		System.out.println("Created new ship: " + ship3);
		System.out.println(harbor.toString());

		
		harbor.anchorShipInHarbor(ship4);
		System.out.println("Created new ship: " + ship4);
		System.out.println(harbor.toString());
		
		//Start by sending one ship to the pier
		System.out.println("Adding 0 to pier: " + harbor.startPier(0));
		System.out.println(harbor.toString());
		//Test to see if the pier is full and if it is reject the 
		//ship trying to enter the pier
		System.out.println("Adding 1 to pier: " + harbor.startPier(1));
		System.out.println(harbor.toString());
		
		//removing one of the ships
		System.out.println("Sailing 0 from harbor.");
		harbor.sailShipFromHarbor(1);
		System.out.println(harbor.toString());
		
		//removing another ship
		System.out.println("Sailing 4 from harbor.");
		harbor.sailShipFromHarbor(2);
		System.out.println(harbor.toString());
		
		//taking a ship out of the pier and putting it back in the harbor
		System.out.println("Ship is done at pier.");
		harbor.donePier();
		System.out.println(harbor.toString());
		
		//add another ship to the pier
		System.out.println("Adding 3 to pier: " + harbor.startPier(3));
		System.out.println(harbor.toString());
		
		//removes an empty ship space from the harbor
		System.out.println("Sailing 2 from harbor.");
		System.out.println(harbor.toString());
		
		//removes the second ship from the pier
		System.out.println("Ship is done at pier.");
		harbor.donePier();
		System.out.println(harbor.toString());
	}

}
