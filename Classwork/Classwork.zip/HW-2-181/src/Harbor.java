

public class Harbor implements LoadingPier, Anchoring {
	

	Ship[] ships = new Ship[5]; // create a 1D array to store the ship values
	Ship pier = null; // create a pier object to store a ship in the pier



	/*
	 * Overrides the implemented LoadingPier interface
	 * to check if the pier is busy 
	 */
	@Override
	public boolean pierIsBusy() {
		if (pier == null) {
			return false;
		}
		return true;
	}

	/*  Overrides the implemented LoadingPier interface
	 * checks if the pier is not busy and the anchorspot contains something
	 * if it does moves a ship variable from the array to the pier object
	 */
	@Override
	public boolean startPier(int anchorSpot) {

		if (ships[anchorSpot] != null && !pierIsBusy()) {
			pier = ships[anchorSpot];
			ships[anchorSpot] = null;

			return true;

		}

		return false;
	}

	/*  Overrides the implemented LoadingPier interface
	 *  checks to see if theres an opens space in the harbor and if there is
	 *  removes the ship from the pier into the open space
	 *  and sets the pier to ope
	 */
	@Override
	public boolean donePier() {
		
		if(pierIsBusy()) {
			this.anchorShipInHarbor(pier);
			pier = null;
			return true;
			
		}
		return false;
				
	}

	/*  Overrides the implemented Anchoring interface
	 * anchores the ship that is declared in the main class and 
	 * checks if the harbor has an open spot
	 */
	@Override
	public boolean anchorShipInHarbor(Ship ship) {
		for (int i = 0; i < ships.length; i++) {
			if (ships[i] == null) {
				ships[i] = ship;

				return true;
			}

		}
		return false;
	}

	/* Overrides the implemented Anchoring interface
	 * removes the ship from the array and from the output
	 */
	@Override
	public void sailShipFromHarbor(int anchorSpot) {
		ships[anchorSpot] = null;

	}

	/* Overrides the implemented Anchoring interface
	 * counts how many ships are in the array and in the harbor
	 * outputs the count of the ships anchored
	 */
	@Override
	public int shipsInHarbor() {
		int count = 0;
		for (int i = 0; i < ships.length; i++) {
			if (!(ships[i] == null)) {
				count++;
			}
		}

		return count;
	}

	/* 
	 * the toString that creates the visible spots in the harbor
	 * and checks to see if the pier is in use if so
	 * then display the pier along with the harbor
	 * also prints out the ships anchored 
	 */
	
	public String toString() {
		String str = "";
		for (int i = 0; i < ships.length; i++) {
			if (ships[i] != null) {
				str += "[" + i + "]" + ships[i].toString() + "\n";
			} else {
				str += "[" + i + "]" + "\n";
			}

		}
		if (pier != null) {
			str += "ship at pier: " + pier.toString();
		}
		return "Ships anchored: " + shipsInHarbor() + "\n" + str + "\n";

	}

}
