
public class Ship {

	private String Shipname; // have the shipname be private so it cannot be changed from the outside
	private int yearBuilt; // have the year be private so it cannot be changed from the outside
	/*
	 * constructor that sets the ship name and year to Unknown and -1 in the 
	 * case that the ship name and year is not given
	 */
	public Ship() {
		Shipname = "Unknown";
		yearBuilt = -1;
	}
	/*
	 * constructor that allows the name and year to be changed within the class
	 */
	public Ship(int year, String name) {
		Shipname = name;
		yearBuilt = year;
	}
	/*
	 *getter that returns the ship name 
	 */
	public String getShipname() {

		return Shipname;
	}
	
	/**
	 * @param shipname
	 */
	public void setShipname(String shipname) {

		Shipname = shipname;

	}

	/**
	 * @return
	 */
	public int getYearBuilt() {

		return yearBuilt;
	}

	/**
	 * @param yearBuilt
	 */
	public void setYearBuilt(int yearBuilt) {
		this.yearBuilt = yearBuilt;
	}

	/* 
	 * 
	 */
	public String toString() {
		if (this.yearBuilt == -1) {

			return Shipname + ", built in unknown ";
		}
		else if (this.Shipname.isEmpty()){

			return "Unknown, built in " + yearBuilt;

		} else {

			return Shipname + ", built in " + yearBuilt;
		}

	}
}
