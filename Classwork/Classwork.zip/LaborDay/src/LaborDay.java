
/*
 * author hackn1a
 * 
 * The program calculates values from a file 
 * and outputs a new array into a new file
 */
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

public class LaborDay {

	public static void main(String[] args) throws IOException {
		// Step 1 Sends the 2D array from readFile to the main method
		String[][] recordTemp = readFile();
		getHI(recordTemp);
	}

	/*
	 * method type: Void read from the file and input it into a 2D array calculates
	 * the Heat index and prints the data 
	 */
	private static void getHI(String[][] recordTemp) {
		//Step 1 create the for loop to parse through the array
		for (int i = 0; i < recordTemp.length; i++) {
			//Step 2 create a 1D array to hold 8 values
			double[] values = new double[8];
			//Step 3 initialize variables within the first and 
			//second for loops 
			double average = 0;
			double max = 0;
			double RH = 0;
			double temp = 0;
			String time = " ";
			String isPrec = " ";
			//Step 4 create a nested for loop to parse through the ccoloms
			for (int j = 0; j < recordTemp[i].length; j++) {
				//Step 5 set time inbetween the second and third for loop
				//to find the time values
				time = recordTemp[i][0];
				//Step 6 create if statments to find the correct time calues
				if (recordTemp[i][j].equals("5:00") || recordTemp[i][j].equals("05:00")
						|| recordTemp[i][j].equals("6:00") || recordTemp[i][j].equals("06:00")
						|| recordTemp[i][j].equals("7:00") || recordTemp[i][j].equals("07:00")
						|| recordTemp[i][j].equals("8:00") || recordTemp[i][j].equals("08:00")
						|| recordTemp[i][j].equals("9:00") || recordTemp[i][j].equals("09:00")
						|| recordTemp[i][j].equals("10:00") || recordTemp[i][j].equals("010:00")
						|| recordTemp[i][j].equals("11:00") || recordTemp[i][j].equals("011:00")
						|| recordTemp[i][j].equals("12:00") || recordTemp[i][j].equals("012:00")
						|| recordTemp[i][j].equals("13:00") || recordTemp[i][j].equals("013:00")
						|| recordTemp[i][j].equals("14:00") || recordTemp[i][j].equals("014:00")
						|| recordTemp[i][j].equals("16:00") || recordTemp[i][j].equals("015:00")
						|| recordTemp[i][j].equals("17:00") || recordTemp[i][j].equals("016:00")
						|| recordTemp[i][j].equals("17:00") || recordTemp[i][j].equals("017:00")) {
					//step 7 create two variables to find the count and 
					//to be able to store he prec from the array
					int count = 0;
					double prec = 0;
					//Step 8 create the third for loop to parse through the array 
					//For the 8 values
					for (int k = i; k < i + 8; k++) {
						//Step 9 now set the variables to parse through the arrays for double values
						temp = Double.parseDouble(recordTemp[k][1]);
						RH = Double.parseDouble(recordTemp[k][2]);
						prec += Double.parseDouble(recordTemp[k][3]);
						double HI = getHI(temp, RH);
						values[count] = HI;
						count++;

					}
					//Step 10 call the other methods to print out the average and max
					average = average(values);
					max = max(values);
					//Step 11 if else statement to find if there was any perc level
					if (max >= 90 || prec > 0) {
						isPrec = "No";

					} else {
						isPrec = "Yes";
					}

				}

			}
			//Step 12
			if (average > 0) {

				if (time.equals("05:00")) {
					time = "5:00";
				}
				if (time.equals("06:00")) {
					time = "6:00";
				}
				if (time.equals("07:00")) {
					time = "7:00";
				}
				if (time.equals("08:00")) {
					time = "8:00";
				}
				if (time.equals("09:00")) {
					time = "9:00";
				}
				//Step 13 print out the data
				System.out.printf("%s, %.2f, %.2f, %s\n", time, average, RH, isPrec);

			}
		}

	}

	/*
	 * method type: double
	 * 
	 * calculates the average of the heat Index
	 * 
	 * return Value: average / recordTemp.length
	 */
	private static double average(double[] recordTemp) {
		double average = 0;
		for (int i = 0; i < recordTemp.length; i++) {
			average += recordTemp[i];
		}
		return average / recordTemp.length;
	}

	/*
	 * method type double calculates the HI of the Temp and the Relative Humidity
	 * and returns the
	 * 
	 * return HI index equation
	 */
	public static double getHI(double T, double RH) {
		double HI = 0;
		HI = -42.379 + 2.04901523 * T + 10.14333127 * RH - .22475541 * T * RH - .00683783 * T * T - .05481717 * RH * RH
				+ .00122874 * T * T * RH + .00085282 * T * RH * RH - .00000199 * T * T * RH * RH;
		return HI;
	}

	/*
	 * method type double calculates the max double value of the heat index and
	 * returns that value into the variable max
	 * 
	 * return value max
	 */
	public static double max(double[] recordTemp) {
		double max = -99999999;
		for (int i = 0; i < recordTemp.length; i++) {
			if (recordTemp[i] > max) {
				max = recordTemp[i];
			}
		}
		return max;
	}

	/*
	 * method type String reads from the file and creates an array to store the
	 * values from the file
	 * 
	 * return recordTemp array
	 */
	private static String[][] readFile() throws FileNotFoundException {

		// Step 1 initialize the file reader and call the file
		File file = new File("LaborDay.csv");

		// Step 2 scan from the file
		Scanner scnr = new Scanner(file);
		// Step 3 initialize any variables
		int rows = 0;
		// Step 4 create a while loop to calculate the number of rows
		while (scnr.hasNext()) {
			rows++;
			scnr.nextLine();

		}
		// Step 5 reinitialize the scnr and the array

		String[][] recordTemp = new String[rows][4];
		scnr = new Scanner(file);
		// Step 6 parse throught the array
		for (int i = 0; i < recordTemp.length; i++) {
			// Step 7 create a new array to set the split function in the rows
			String values[] = scnr.nextLine().split(",");

			for (int j = 0; j < recordTemp[i].length; j++) {

				recordTemp[i][j] = values[j];

			}

		}
		// Step 8 return the recordTemp array
		return recordTemp;

	}

}