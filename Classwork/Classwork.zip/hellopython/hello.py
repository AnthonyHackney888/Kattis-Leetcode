

'''
Created on May 26, 2019

@author: ahack
'''
from numpy import *

feature_set = np.array([[0,1,0],[0,0,1],[1,0,0],[1,1,0],[1,1,1]])
labels = np.array([[1,0,0,1,1]])
labels = labels.reshape(5,1)

# np.random.seed(42)
# weights = np.random.rand(3,1)
# bias = np.random.rand(1)
# lr = 0.05

def sigmoid(x):
    return 1/(1+np.exp(-x))

def sigmoid_der(x):
    return sigmoid(x)*(1-sigmoid(x))