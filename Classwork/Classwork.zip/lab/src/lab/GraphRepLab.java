package lab;
/*
 * author: Anthony Hackney
 * Date: 9/02/19
 * This program shows the connections between vertices and edges.
 */
import java.util.LinkedList;

public class GraphRepLab {

	public static void main(String[] args) {

		GraphRepLab graphObj = new GraphRepLab(6);
		graphObj.populateMatrix();
		graphObj.populateAdjLists();
		graphObj.printGraphs();

	}

	/**
	 * adjMatrix: adjacency matrix to represent a graph
	 */
	public int[][] adjMatrix;
	/**
	 * adjList: adjacency lists to represent a graph
	 */
	public LinkedList<Integer>[] adjList;

	/**
	 * Constructor GraphRepLab
	 * 
	 * @param numVertices number of vertices in the graph
	 */
	public GraphRepLab(int numVertices) {

		// initialize with the graph size
		adjMatrix = new int[numVertices][numVertices];
		adjList = new LinkedList[numVertices];

		// create an array of linked lists
		for (int i = 0; i < adjList.length; i++) {
			adjList[i] = new LinkedList<Integer>();
		}

	}

	/**
	 * populateMatrix populate the graph representation matrix
	 */
	public void populateMatrix() {

		// now put 1s to represent the appropriate edges
		// in the adjMatrix
		adjMatrix[0][1] = 1; // 0 connected to 1
		adjMatrix[0][2] = 1; // 0 connected to 2
		adjMatrix[1][3] = 1; // 1 connected to 3
		adjMatrix[2][3] = 1; // 2 connected to 3
		adjMatrix[3][4] = 1; // 3 connected to 4
		adjMatrix[4][5] = 1; // 4 connected to 5

	}

	/**
	 * populateAdjLists populate the graph representation matrix
	 */
	public void populateAdjLists() {

		// now add vertice numbers to represent the
		// appropriate edges in the adjList
		adjList[0].add(1);
		adjList[0].add(2);
		adjList[1].add(3);
		adjList[2].add(3);
		adjList[3].add(4);
		adjList[4].add(5);

		// add code here

	}

	/**
	 * printMatrix print out the graph representation
	 */
	public void printMatrix() {
		System.out.println("------------GRAPH FROM MATRIX---------------");
		//initial for loop
		for (int i = 0; i < 6; i++) {
			//start of the print statement to shwo was is connected
			System.out.print(i + " is connected to: ");
			//nested for loop
			for (int j = 0; j < 6; j++) {
				//if statement to check if the elements in the matrix have a 1
				if (adjMatrix[i][j] == 1) {
					
					System.out.print(j + " ");
				}
			}
			System.out.println();
		}
System.out.println();
	}

	/**
	 * printAdjLists print out the adjacency lists representation
	 */
	public void printAdjLists() {

		System.out.println("------------GRAPH FROM ADJACENCY LIST---------------");
		//Initial for loop 
		for (int i = 0; i < 6; i++) {
			//start of the print statement
			System.out.print(i + " is connected to ");
			//nested for loop to show what is connected
			for (int j = 0; j < 6; j++) {
				//if statement to check if the adjacency list is connected to anything
				if (adjList[i].contains(j)) {
					//print the connection
					System.out.print(j + " ");
				}
				
			}
			System.out.println();
		}


	}

	public void printGraphs() {
		printMatrix();
		printAdjLists();
	}

}
