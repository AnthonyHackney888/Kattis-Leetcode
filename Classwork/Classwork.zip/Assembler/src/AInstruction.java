import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class AInstruction extends FileWorker {

	private JFrame frame;
	private static ArrayList<String> rom = new ArrayList<>();
	private static HashMap<String, Integer> symbolTable = new HashMap<String, Integer>();
	

	/**
	 * Launch the application.
	 */
	public static void newWindow() {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AInstruction window = new AInstruction();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AInstruction() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Assembler");
		frame.setBounds(100, 100, 685, 771);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);

		JTextArea textArea = new JTextArea();
		textArea.setEditable(true);
		textArea.setBounds(10, 45, 223, 633);
		JScrollPane scrollBar = new JScrollPane(textArea);
		scrollBar.setBounds(10, 45, 223, 633);
		panel.add(scrollBar);

		JLabel label = new JLabel("");
		label.setBounds(26, 26, 46, 14);
		panel.add(label);

		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser saveFile = new JFileChooser();
				saveFile.setDialogTitle("Save as: ");
				int result = saveFile.showSaveDialog(null);
				if (result == JFileChooser.APPROVE_OPTION) {
					String content = textArea.getText();
					File f = saveFile.getSelectedFile();

					try {
						FileWriter fw = new FileWriter(f.getPath());
						fw.write(content);
						fw.flush();
						fw.close();
					} catch (Exception e) {

					}
				}
			}
		});
		btnSave.setBounds(553, 689, 89, 23);
		panel.add(btnSave);

		JTextArea textArea_1 = new JTextArea();
		textArea_1.setEditable(true);
		textArea_1.setBounds(421, 46, 221, 631);
		JScrollPane scrollBar2 = new JScrollPane(textArea_1);
		scrollBar2.setBounds(421, 46, 221, 631);
		panel.add(scrollBar2);

		Label label_1 = new Label("Output");
		label_1.setBounds(507, 11, 62, 22);
		panel.add(label_1);

		Label label_2 = new Label("Input");
		label_2.setBounds(134, 11, 62, 22);
		panel.add(label_2);

		JButton backBtn = new JButton("Back");
		backBtn.setBounds(10, 11, 89, 23);
		panel.add(backBtn);

		JButton btnOpenFile = new JButton("Open File");
		btnOpenFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser chooser = new JFileChooser();
				chooser.showOpenDialog(null);
				File f = chooser.getSelectedFile();
				String filename = f.getAbsolutePath();
				String extrabit;

				try {
					FileReader reader = new FileReader(filename);

					BufferedReader br = new BufferedReader(reader);
					while ((extrabit = br.readLine()) != null) {
						String firstSymbol;
						int address = 0;

						extrabit = extrabit.replaceAll("//.*$", "").trim();
						if (extrabit.equals("")) {
							continue;
						}
						System.out.println(extrabit);
						rom.add(extrabit);
						if (extrabit.startsWith("(")) {
							firstSymbol = extrabit;
							if (!symbolTable.containsKey(firstSymbol))
								symbolTable.put(firstSymbol, address);
						} else {
							address++;
						}
						textArea.append(extrabit+"\n");
						
					}

					
					br.close();

				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});
		btnOpenFile.setBounds(10, 689, 89, 23);
		panel.add(btnOpenFile);
		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				popUp pu = new popUp();
				pu.main(null);

			}

		});

	}
	
}

	


