import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 * @author hackn1a
 * 
 * This program is supposed to convert a .asm file to .hack
 *
 */
public class Main {
//initialize the array and hashmaps
	private static ArrayList<String> rom = new ArrayList<>();
	private static HashMap<String, Integer> symbolTable = new HashMap<String, Integer>();
	private static HashMap<String, String> dest = new HashMap<String, String>();
	private static HashMap<String, String> comp = new HashMap<String, String>();
	private static HashMap<String, String> jump = new HashMap<String, String>();

	public static void main(String[] args) throws IOException {
		//have the user input their file
		String userInput;
		@SuppressWarnings("resource")
		Scanner personScnr = new Scanner(System.in);
		System.out.println("please enter in the file name: ");
		userInput = personScnr.nextLine();
		File f = new File(userInput);
		@SuppressWarnings("resource")
		Scanner scnr = new Scanner(f);
		String firstSymbol;
		int address = 0;
		System.out.println("first Pass");
		//delete the comments and the spaces
		while (scnr.hasNext()) {

			String extrabit = scnr.nextLine();
			extrabit = extrabit.replaceAll("//.*$", "").trim();
	
			if (extrabit.equals("")) {
				continue;
			}
			//add the clean file into the arraylist
			rom.add(extrabit);
			if (extrabit.startsWith("(")) {
				firstSymbol = extrabit;
				if (!symbolTable.containsKey(firstSymbol))
					symbolTable.put(firstSymbol, address);
			} else {
				address++;
			}
//print the rest of the file to test
			System.out.println(extrabit);
		}
		System.out.println();
		printROM(rom);
		symbolTable();
		AInstruction();
		System.out.println();
		
		
			
	}

	
	/**
	 * @throws FileNotFoundException in case the file is not available
	 * This methods acts as the second pass and the A instruction
	 */
	public static void AInstruction() throws FileNotFoundException{
	
		String symbolName = " ";
		Integer address = 16;
		String rom3;
		Integer rom2;
		String binary = "";
		String sy = "@";
		//looks for symbols that start with @ to add them into the symbol table
		for (int i = 0; i < rom.size(); i++) {
			if (rom.get(i).startsWith(sy)) {
				symbolName = rom.get(i);
			}
			if (!symbolTable.containsKey(symbolName)) {
				symbolTable.put(symbolName, address);
				address++;

			}
			if (rom.get(i).trim().charAt(0) == '@') {
				rom2 = symbolTable.get(symbolName);
				rom3 = Integer.toBinaryString(rom2);
				int n = address - rom3.length();

				for (int j = 0; j < n; j++) {
					rom3 = "0" + rom3;
				}
				
				System.out.println(rom.get(i) + "\t" + rom3);
				
			}else {
					binary = cInstruction(rom.get(i));
				}
			
		}//Takes in a userInput to save the file as a specific .hh file
		System.out.println("save the file as: ");
		Scanner scnr = new Scanner(System.in);
		String userInput = scnr.nextLine();
		File file = new File(userInput);
		PrintWriter pw = new PrintWriter(file);
		pw.println(binary);
		pw.close();

	}

	/**
	 * @param Cin the Cinstruction symbols
	 * @return 
	 * This method translates the C instruction for the .asm file
	 */
	public static String cInstruction(String Cin) {
		String bin = "";
		String dest = "";

		String jump = "";
		String comp = Cin;

		// find any equal sign and use the indexOf function to remove it from the line
		if (Cin.contains("=")) {
			dest = comp.substring(0, comp.indexOf("="));
			comp = comp.substring(comp.indexOf("=") + 1);
		}

		// find any ; character and use the indexOf function to remove it from the line
		if (Cin.contains(";")) {
			if (Cin.contains("=")) {
				comp = comp.substring(comp.indexOf("=") + 1, comp.indexOf(";"));
				jump = comp.substring(comp.indexOf(";") + 1);
			} else {

				jump = comp.substring(comp.indexOf(";") + 1);
				comp = comp.substring(0, comp.indexOf(";"));
			}
		}

		// use the methods to find the binary within the hashmaps in their own methods
		
		String binDest = dest(dest);
		String binComp = comp(comp);
		String binJump = jump(jump);

		// initialize the binary for C instruction
		bin = "111" + binComp + binDest + binJump;

		System.out.println(Cin + "\t" + bin); // print C instruction binary

		return bin;

	}

	

	/**
	 * @param rom name of the arrayList
	 * 
	 * 	this is to print the rom arraylist
	 */
	public static void printROM(ArrayList<String> rom) {
		System.out.println(rom);
	}

	/**
	 * @throws FileNotFoundException if there is not a file
	 * 
	 * This method is to hardcode the pre defined labels into the hashmaps
	 */
	public static void symbolTable() {
		symbolTable.put("R0", 0);
		symbolTable.put("R1", 1);
		symbolTable.put("R2", 2);
		symbolTable.put("R3", 3);
		symbolTable.put("R4", 4);
		symbolTable.put("R5", 5);
		symbolTable.put("R6", 6);
		symbolTable.put("R7", 7);
		symbolTable.put("R8", 8);
		symbolTable.put("R9", 9);
		symbolTable.put("R10", 10);
		symbolTable.put("R11", 11);
		symbolTable.put("R12", 12);
		symbolTable.put("R13", 13);
		symbolTable.put("R14", 14);
		symbolTable.put("R15", 15);
		symbolTable.put("SP", 0);
		symbolTable.put("LCL", 1);
		symbolTable.put("ARG", 2);
		symbolTable.put("THIS", 3);
		symbolTable.put("THAT", 4);
		symbolTable.put("SCREEN", 16384);
		symbolTable.put("KBD", 24576);
	}
		
		/**
		 * @param dest2 the dest symbol
		 * @return returns the value of dest
		 * hardcodes the dest into the hashmap
		 */
		public static String dest(String dest2) { 
		dest.put("null", "000");
		dest.put("M", "001");
		dest.put("D", "010");
		dest.put("MD", "011");
		dest.put("A", "100");
		dest.put("AM", "101");
		dest.put("AD", "110");
		dest.put("AMD", "111");
		String c = dest.get(dest2);
		return c;
		}
		/**
		 * @param comp2 the comp symbol
		 * @return returns the comp
		 * hardcodes the comp into the hashmap
		 */
		public static String comp(String comp2) {
		comp.put("0", "0101010");
		comp.put("1", "0111111");
		comp.put("-1", "0111010");
		comp.put("D", "0001100");
		comp.put("A", "0110000");
		comp.put("!D", "0001101");
		comp.put("!A", "0110001");
		comp.put("-D", "0001111");
		comp.put("-A", "0110011");
		comp.put("D+1", "0011111");
		comp.put("A+1", "0110111");
		comp.put("D-1", "0001110");
		comp.put("A-1", "0110010");
		comp.put("D+A", "0000010");
		comp.put("D-A", "0010011");
		comp.put("A-D", "0000111");
		comp.put("D&A", "0000000");
		comp.put("D|A", "0010101");
		comp.put("M", "1110000");
		comp.put("!M", "1110001");
		comp.put("-M", "1110011");
		comp.put("M+1", "1110111");
		comp.put("M-1", "1110010");
		comp.put("D+M", "1000010");
		comp.put("D-M", "1010011");
		comp.put("M-D", "1000111");
		comp.put("D&M", "1000000");
		String b = comp.get(comp2);
		return b;
		}
		/**
		 * @param jump2 the jump symbol
		 * @return the jump
		 * hardcodes the jump into the hashmap
		 */
		public static String jump(String jump2) {
		jump.put("null", "000");
		jump.put("JGT", "001");
		jump.put("JEQ", "010");
		jump.put("JGE", "011");
		jump.put("JLT", "100");
		jump.put("JNE", "101");
		jump.put("JLE", "110");
		jump.put("JMP", "111");
		String a = jump.get(jump2);
		return a;
		
	}
}
