import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Ain extends FileWorker {
	private static HashMap<String, Integer> dest = new HashMap<String, Integer>();
	private static HashMap<String, Integer> comp = new HashMap<String, Integer>();
	private static HashMap<String, Integer> jump = new HashMap<String, Integer>();
	private static ArrayList<String> rom = new ArrayList<>();
	private static HashMap<String, Integer> symbolTable = new HashMap<String, Integer>();
	
	public static HashMap<String, Integer> aI()throws IOException {
	
		
		File f = new File("SumN.asm");

		@SuppressWarnings("resource")
		Scanner scnr = new Scanner(f);
	
		String symbolName = " ";
		Integer address = 16;
		Integer intValue;
		String binary = "";
		String sy = "@";
		while(scnr.hasNext()) {
		for (int i = 0; i < rom.size(); i++) {
			if (rom.get(i).startsWith(sy)) {
				symbolName = rom.get(i);
			}
			if (!symbolTable.containsKey(symbolName)) {
				symbolTable.put(symbolName, address);
				address++;

			}else if(symbolTable.containsKey(symbolName)) {
				
				intValue = Integer.valueOf(address);
				binary = Integer.toBinaryString(intValue); 
			}

		}
}
		
		System.out.println(symbolTable);
		System.out.println(String.format("%1$15s", binary).replace(" ", "0"));
		return symbolTable;
	}

//System.out.println(symbolTable.get(address));
	
	public static void printROM(ArrayList<String> rom) {
		System.out.println(rom);
	}

	public static void symbolTable() throws FileNotFoundException {
		symbolTable.put("R0", 0);
		symbolTable.put("R1", 1);
		symbolTable.put("R2", 2);
		symbolTable.put("R3", 3);
		symbolTable.put("R4", 4);
		symbolTable.put("R5", 5);
		symbolTable.put("R6", 6);
		symbolTable.put("R7", 7);
		symbolTable.put("R8", 8);
		symbolTable.put("R9", 9);
		symbolTable.put("R10", 10);
		symbolTable.put("R11", 11);
		symbolTable.put("R12", 12);
		symbolTable.put("R13", 13);
		symbolTable.put("R14", 14);
		symbolTable.put("R15", 15);
		symbolTable.put("SP", 0);
		symbolTable.put("LCL", 1);
		symbolTable.put("ARG", 2);
		symbolTable.put("THIS", 3);
		symbolTable.put("THAT", 4);
		symbolTable.put("SCREEN", 16384);
		symbolTable.put("KBD", 24576);
		System.out.println(symbolTable);

	}

	public static void otherTables() {
		dest.put("null", 000);
		dest.put("M", 001);
		dest.put("D", 010);
		dest.put("MD", 011);
		dest.put("A", 100);
		dest.put("AM", 101);
		dest.put("AD", 110);
		dest.put("AMD", 111);

		comp.put("0", 0101010);
		comp.put("1", 0111111);
		comp.put("-1", 0111010);
		comp.put("D", 0001100);
		comp.put("A", 0110000);
		comp.put("!D", 0001101);
		comp.put("!A", 0110001);
		comp.put("-D", 0001111);
		comp.put("-A", 0110011);
		comp.put("D+1", 0011111);
		comp.put("A+1", 0110111);
		comp.put("D-1", 0001110);
		comp.put("A-1", 0110010);
		comp.put("D+A", 0000010);
		comp.put("D-A", 0010011);
		comp.put("A-D", 0000111);
		comp.put("D&A", 0000000);
		comp.put("D|A", 0010101);
		comp.put("M", 1110000);
		comp.put("!M", 1110001);
		comp.put("-M", 1110011);
		comp.put("M+1", 1110111);
		comp.put("M-1", 1110010);
		comp.put("D+M", 1000010);
		comp.put("D-M", 1010011);
		comp.put("M-D", 1000111);
		comp.put("D&M", 1000000);

		jump.put("null", 000);
		jump.put("JGT", 001);
		jump.put("JEQ", 010);
		jump.put("JGE", 011);
		jump.put("JLT", 100);
		jump.put("JNE", 101);
		jump.put("JLE", 110);
		jump.put("JMP", 111);

	}

}
