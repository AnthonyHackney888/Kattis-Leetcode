import java.io.File;
import java.util.HashMap;

public class Cin {
	File f;
	HashMap<String, Integer> symbolTable;
	HashMap<String, Integer> comp;
	HashMap<String, Integer> jump;
	HashMap<String, Integer> dest;


	public File getF() {
		return f;
	}
	
	
	

}
