import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Reader {
	ArrayList<String> array = new ArrayList<>();
	private String question;
	private String answer;

	public Reader(String question, String answer) {
		this.answer = answer;
		this.question = question;
	}

	public void readfile() throws FileNotFoundException {

		File f = new File("questions.txt");
		Scanner scnr = new Scanner(f);

		while (scnr.hasNext()) {
			for (String line : array) {
				line.split(".");
			}
		}
		for (String print : array) {
			System.out.println(print);
		}
	}
}
