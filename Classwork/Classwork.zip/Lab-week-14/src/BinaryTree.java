
public class BinaryTree {

    public Node root = null;

    public BinaryTree() {
    }

    public Integer getMin() {
        if (root == null) {
            return null;
        } else {
            return leftMost(root).value;
        }
    }

    private Node leftMost(Node n) {
        if (n.left != null) {
            leftMost(n.left);
        }
        return n;
    }

    public void add(Integer obj) {
        Node n = new Node(obj);
        if (root == null) {
            root = n;
        } else {
            this.add(root, n);
        }
    }
    public void preorder(Node p) {
    	while (p!=null) {
    		System.out.println(p.value);
    		p = p.left;
    	}
    }
    public void inOrder(Node p) {
    	while(p!=null) {
    		System.out.println(p.right);
    		p = p.left;
    	}
    }

    private void add(Node r, Node n) {
        if (r.value > n.value) {
            if (r.left == null) {
                r.left = n;
            } else {
                add(r.left, n);
            }
        } else {
            if (r.right == null) {
                r.right = n;
            } else {
                add(r.right, n);
            }
        }

    }  
   private class Node {
        Integer value;
        Node left = null;
        Node right = null;

        public Node(Integer obj) {
            value = obj;
        }

        public Node(Integer obj, Node leftChild, Node rightChild) {
            value = obj;
            left = leftChild;
            right = rightChild;
        }
    }
}