import java.util.Random;

import javax.xml.soap.Node;

/*
 * author hackn1a
 */
public class Main {

	
		 public static void main(String[] args) {
		        Random rand = new Random();

		        BinaryTree bintree = new BinaryTree();

		    bintree.add(5);
		    bintree.add(15);
		    bintree.add(55);
		    bintree.add(100);
		    bintree.add(4);
		   
		    
		    
		    bintree.preorder(null);
		    bintree.inOrder(null);
		}
}
