import java.util.Random;
import java.util.Scanner;
/* 
 *    Author: Anthony Hackney
 *    Date: 02/21/18
 *    
 *    Description: Play Rock paper and scissors with a computer
 *    making sure the user uses specific characters and
 *    make sure the user does not leave the prompts empty
 */

public class PaperRockScissors {

	public static void main(String args[]) {
		char usersThrow = ' ';
		char computersThrow = ' ';
		String userResponse = " ";
		String userName = " ";

		// Initialize a keyboard tied scanner and random number generator
		Scanner scnr = new Scanner(System.in);
		Random randGen = new Random();

		// Step 1: Determine the throw of the computer player
		switch (randGen.nextInt(100) % 3) {
		case 0:
			computersThrow = 'p';
			break;
		case 1:
			computersThrow = 'r';
			break;
		case 2:
			computersThrow = 's';
			break;

		}

		// Step 2: Prompt the user for their name and what they throw
		// if there is no response prompt the user again
		System.out.println("Player 1, please print your full name: ");
		userName = scnr.nextLine();

		// Step 3: initialize a new scanner to print out just the users name
		Scanner firstN = new Scanner(userName);
		userName = firstN.next();

		while (userName.isEmpty()) {
			System.out.println("Invalid Input, try again. ");
			System.out.println("Player 1, please print your full name: ");
			userName = scnr.nextLine();
		}

		System.out.println("What do you want to throw? [p,r,s] ");
		userResponse = scnr.nextLine();
		while (userResponse.isEmpty()) {
			System.out.println("Invalid Input, try again. ");
			System.out.println("What do you want to throw? [p,r,s] ");
			userResponse = scnr.nextLine();
		}

		// Step 4: while loops and if else statements
		usersThrow = userResponse.charAt(0);

		while (usersThrow != 'p' && usersThrow != 'r' && usersThrow != 's') {
			System.out.println("Invalid Input, try again. ");
			System.out.println("What do you want to throw? [p,r,s] ");
			userResponse = scnr.nextLine();
			usersThrow = userResponse.charAt(0);
		}
		if (usersThrow == computersThrow) {
			System.out.println("You threw a '" + usersThrow 
					+ "' and the computer threw '" + computersThrow + "' ");
			System.out.println(userName + ", you and the computer tied!");

		} else if (usersThrow == 'r' && computersThrow == 's') {
			System.out.println("You threw a '" + usersThrow 
					+ "' and the computer threw '" + computersThrow + "' ");
			System.out.println(userName + ", you won!");

		} else if (usersThrow == 's' && computersThrow == 'p') {
			System.out.println("You threw a '" + usersThrow 
					+ "' and the computer threw '" + computersThrow + "' ");
			System.out.println(userName + ", you won!");

		} else if (usersThrow == 'p' && computersThrow == 'r') {
			System.out.println("You threw a '" + usersThrow 
					+ "' and the computer threw '" + computersThrow + "' ");
			System.out.println(userName + ", you won!");

		} else {
			System.out.println("You threw a '" + usersThrow 
					+ "' and the computer threw '" + computersThrow + "' ");
			System.out.println("sorry, " + userName + ", you lost.");

		}
		firstN.close();
		scnr.close();
	}
}