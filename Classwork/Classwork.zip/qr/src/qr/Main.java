package qr;

import java.util.Scanner;

// Project 1 DJ format


class LinkedList extends Object {
  private int data;
  private LinkedList next;
  private LinkedList head; //linkedlist variable for the head node
  public void setData(int newData) { 
	data=newData; 
  }
  
  
  //The list is in reversed order, always return 0
  //when adding a number itll need to be preappended 
  public int prepend(Integer newData) {
	 LinkedList l = new LinkedList();
	 LinkedList first = null; 
	 LinkedList crnt = head;
	 while(crnt != null) {
		 if(crnt.next == null) {
			 crnt.next = setData(newData);
			 break;
		 }
		 crnt = crnt.next;
	 }
	 
	//while the ptr is not null crnt will be set to the ptr
	//then the ptr will be set to the next value
	//the crnt will be set the the value that the ptr was at
	//first is set to crnt and the head node will be set to crnt
	/* 
	 while(ptr != null) {
		 crnt = ptr;
		 ptr = ptr.next;
		 crnt.next = first;
		 first = crnt;
		 head = crnt;
	 }
    */
    return 0;
  }

  //extract an emelent from list, return it
  public int getElement(int index, int target, LinkedList list) {
	  int counter = 0;
	  LinkedList crnt = head;
	  while (crnt != null) {
		  if (counter == target) {
			  	return crnt.data;
		  }
		  counter++;
		  crnt = crnt.next;
	  }
	return 0;
  }

  //get the quotient and remainder, always return 0
  public int getQR(int firstElement, int secondElement) {
    // You need to implement this function
	  LinkedList list;
	  int something = getElement(setData(something),firstElement, list);
	  
	  while(firstElement != null || secondElement != null) {
		  
	  }
	
	return 0;
  }



public static void main (String[] args) {
  // You need to implement this method
  //for java testing
  Scanner scnr = new Scanner(System.in);
  LinkedList list = new LinkedList();
  
  list.getQR(1,2);
  
}

}