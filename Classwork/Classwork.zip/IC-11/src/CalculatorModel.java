public class CalculatorModel {

	private double a;	// operand 1
	private double b;	// operand 2

	/*
	 * ---------------------------
	 * Getters and Setters
	 * ---------------------------
	 */
	public double getA() {
		return a;
	}
	public void setA(double a) {
		this.a = a;
	}
	public double getB() {
		return b;
	}
	public void setB(double b) {
		this.b = b;
	}

	/**
	 * Finds the sum of operands a and b
	 * 
	 * @return sum of a and b
	 */
	public double add() {
		return a+b;
	}


	/**
	 * Finds the difference of operands a and b
	 * @return difference of a and b
	 */
	public double sub() {
		return a-b;
	}

	/**
	 * Finds the product of operands a and b
	 * @return product of a and b
	 */
	public double mul() {
		return a*b;
	}

	/**
	 * Finds the quotient of operands a and b
	 * @return quotient of a and b
	 */
	public double div() {
		return a/b;
	}
	

	
}