/**
 * 
 * @author hackn1a
 * 
 * fixed the missing operations in the calculator
 */

public class CalcMain {

	public static void main(String[] args) {

		System.out.println("Start of main program");

		CalculatorModel mdl = new CalculatorModel();

		CalculatorView view = new CalculatorView();

		CalculatorController ctrl = new CalculatorController(mdl, view);
		ctrl.setupController();

	}

}