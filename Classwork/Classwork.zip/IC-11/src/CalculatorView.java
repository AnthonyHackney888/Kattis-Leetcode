

import java.awt.*;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class CalculatorView extends JFrame {

	private TextField inputTF1;
	private TextField inputTF2;
	private Label resultLabel;

	private Button addBtn;
	private Button subBtn;
	private Button mulBtn;
	private Button divBtn;

	/**
	 * Constructor. Sets up the frame by calling methods from the parent class.
	 * Sets up the frame layout, then creates the text field & labels for the operands
	 * and the results. Creates the buttons for the operations and then adds all
	 * of the items to the frame.
	 */
	public CalculatorView() {

		// Setup Frame
		setSize(300,250);		// size of window
		setLayout(null);		// no layout is required for this
		setVisible(true);		// a visible window
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);

		// Text Field Labels
		Label opLabel1 = new Label("Op 1:");	// a label, which just present text
		opLabel1.setBounds(25,50,50,25);		// the location and size of the label (x, y, size_x, size_y)

		Label opLabel2 = new Label("Op 2:");
		opLabel2.setBounds(25,75,50,25);

		Label resultTextLabel = new Label("Result:");
		resultTextLabel.setBounds(25,125,50,25);

		resultLabel = new Label("Press the operation buttons to calculate.");
		resultLabel.setBounds(25,150,250,25);

		// Text Field (a TextField takes in user input)
		inputTF1 = new TextField();			// operand 1
		inputTF1.setBounds(75, 50, 100, 25);
		inputTF2 = new TextField();			// operand 2
		inputTF2.setBounds(75, 75, 100, 25);

		// Buttons
		addBtn = new Button("+");			// add
		addBtn.setBounds(200,50,50,25);
		subBtn = new Button("--");			// sub
		subBtn.setBounds(200,75,50,25);
		mulBtn = new Button("*");			// multiply
		mulBtn.setBounds(200,100,50,25);
		divBtn = new Button("/");			// divide
		divBtn.setBounds(200,125,50,25);

		// Add to Frame (if you do not add them to the frame, they will not appear)
		add(opLabel1);
		add(opLabel2);
		add(resultTextLabel);
		add(resultLabel);
		add(inputTF1);
		add(inputTF2);
		add(addBtn);
		add(subBtn);
		add(mulBtn);
		add(divBtn);
	}

	/*
	 * ---------------------------
	 * Getters and Setters
	 * ---------------------------
	 */
	// returns the operand 1 text field object
	public TextField getInputTF1() {
		return this.inputTF1;
	}

	// returns the operand 2 text field object
	public TextField getInputTF2() {
		return this.inputTF2;
	}

	// returns the result label object
	public Label getResultLabel() {
		return this.resultLabel;
	}
	
	// returns the private variable addBtn
	public Button getAddBtn() {
		return this.addBtn;
	}

	// returns the private variable subBtn
	public Button getSubBtn() {
		return this.subBtn;
	}

	// returns the private variable mulBtn
	public Button getMulBtn() {
		return this.mulBtn;
	}

	// returns the private variable divBtn
	public Button getDivBtn() {
		return this.divBtn;
	}
}