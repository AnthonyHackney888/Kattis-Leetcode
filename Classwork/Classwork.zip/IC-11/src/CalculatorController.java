

import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorController {

	private CalculatorModel model = null;
	private CalculatorView view = null;


	/**
	 * Stores references to the model and view objects to make sure the controller
	 * can access both the model and view objects for later on. The model is used for
	 * the actual mathematical operations and the view is used to detect button
	 * presses and update the graphics interface.
	 * 
	 * @param model The model being used for mvc
	 * @param view The view being used for mvc
	 */
	public CalculatorController( CalculatorModel model, CalculatorView view ) {
		this.model = model;
		this.view = view;
	}

	/**
	 * Sets up the button ActionListeners for the buttons that are in the view object.
	 * Performs the appropriate operation by calling the performOperation() method,
	 * dependent upon which button is pressed.
	 */
	public void setupController() {
		view.getAddBtn().addActionListener( new ActionListener() {
			public void actionPerformed( ActionEvent e) {
				performOperation(0);
			}
		} );

		view.getSubBtn().addActionListener( new ActionListener() {
			public void actionPerformed( ActionEvent e) {
				performOperation(1);
			}
		} );

		view.getMulBtn().addActionListener( new ActionListener() {
			public void actionPerformed( ActionEvent e) {
				performOperation(2);
			}
		} );

		view.getDivBtn().addActionListener( new ActionListener() {
			public void actionPerformed( ActionEvent e) {
				performOperation(3);
			}
		} );

	}

	/**
	 * This method calls the model class to perform the operation and updates the view.
	 * The first and second operands are received by passing the TextField objects from
	 * the view getter. The model's values are set. Takes in a flag parameter to mark
	 * the operation and the model's method is called to perform the actual operation.
	 * The result is updated on the view by updating the Label object.
	 * 
	 * @param flag the mathematical operation to perform
	 */
	public void performOperation( int flag ) {
		double op1 = getOperand( view.getInputTF1() );
		double op2 = getOperand( view.getInputTF2() ); 
		model.setA( op1 );
		model.setB( op2 );

		double result = 0;

		switch( flag ) {
		case 0:
			result = model.add();
			break;
		case 1:
			result = model.sub();
			break;
		case 2:
			result = model.mul();
			break;
		case 3:
			result = model.div();
			break;
		default:
			// TODO: should throw
			result = 0;
		}
		
		view.getResultLabel().setText( "" + result );
	}
	
	/**
	 * Receives a TextField object as a parameter. The String text from the object is
	 * converted into a double and returned. The value 0 is returned and an error message
	 * is printed to the standard error if there is an error with the operation.
	 * 
	 * @param tf the Textfield to update
	 */
	public double getOperand( TextField tf ) {
		try {
			return Double.parseDouble( tf.getText() );
		} catch (Exception e) {
			System.err.println("There was an error in the operand choice. Make sure the value is numeric.");
			return 0;
		}
	}
}