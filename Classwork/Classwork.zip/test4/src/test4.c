/*
 ============================================================================
 Name        : Days.c
 Author      : Matthew Drain drain1ma
 Version     :
 Copyright   : Your copyright notice
 Description : Provides the number of days through the year by user input
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
void met1(int largest);
int met2(int d[], size);
int main(void) {


	int data[5] = {1,2,3,4,20};
	int size;
	size = 5;

	/*int January = 31;
		int February = 28;
		int March = 31;
		int April = 30;
		int May = 31;
		int June = 30;
		int July = 31;
		int August = 31;
		int September = 30;
		int October = 31;
		int November = 30;
		int December = 31;
		int month;
		int day;
		int year;
		int numOfDays;
	setvbuf(stdout, NULL, _IONBF, 0);

	printf("Enter the date using only numbers (MM DD YYYY):  ");


	scanf("%d%d%d", &month, &day, &year); //Allow for user input for the date

	numOfDays = day;


		if (year % 4 == 0){
			February = 29;

		}
		if (month > 12){
            printf("There can only be 12 months.");
		}
        if (month < 0){
            printf("The month must be a positive integer value.");
        }
        if (day < 0){
            printf("The day must be a positive integer value.");
        }
        if (day > 31){
            printf("There can only be a certain amount of days.");
        }



			switch(month){
			case 2:
				numOfDays += January;
				break;
			case 3:
				numOfDays += January + February;
				break;
			case 4:
				numOfDays += January + February + March;
				break;
			case 5:
				numOfDays += January + February + March + April;
				break;
			case 6:
				numOfDays += January + February + March + April + May;
				break;
			case 7:
				numOfDays += January + February + March + April + May + June;
				break;
			case 8:
				numOfDays += January + February + March + April + May + June + July;
				break;
			case 9:
				numOfDays += January + February + March + April + May + June + July + August;
				break;
			case 10:
				numOfDays += January + February + March + April + May + June + July + August + September;
				break;
			case 11:
				numOfDays += January + February + March + April + May + June + July + August + September + October;
				break;
			case 12:
			numOfDays += January + February + March + April + May + June + July + August + September + October + November;
				break;
			case 13:
			numOfDays += January + February + March + April + May + June + July + August + September + October + November + December;
				break;
			}

			if (month < 13 && month > 0 && day > 0){
			printf("Number of days: %d", numOfDays);
			}
*/

met1(met2(data,size));

return 0;
}
void met1(int largest){
	printf("%d",largest);


}
int met2(int d[], size){
	int max = 0;
	for(int i = 0; i < size; i++){
		if(d[i] > max){
			max = d[i];
		}
	}
	return max;
}


