
public class Brain {
	private int age;
	
	public void hello() {
		System.out.println("I am a brain.");
	}
}
