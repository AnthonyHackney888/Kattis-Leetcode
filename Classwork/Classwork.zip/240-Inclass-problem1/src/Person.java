
public class Person {
	private Brain brain;
	private Job job;
	public Person() {
		this.job = new Job();
		this.brain = new Brain();
	}
	public Job getJob() {
		return job;
	}
	public void setJob(Job job) {
		this.job = job;
	}
	public Brain getBrain() {
		return brain;
	}
	
}
